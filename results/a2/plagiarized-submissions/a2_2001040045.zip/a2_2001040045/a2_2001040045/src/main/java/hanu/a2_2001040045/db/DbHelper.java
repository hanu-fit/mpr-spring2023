package hanu.a2_2001040045.db;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class DbHelper extends SQLiteOpenHelper {
    private Context mContext;
    public static final String DB_NAME = "product_carts.db";
    public static final int DB_VERSION = 1;

    public DbHelper(@Nullable Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL("CREATE TABLE " + DbSchema.ProductCartTable.DB_NAME + "("
                                + "id INTEGER PRIMARY KEY AUTOINCREMENT, "
                                + DbSchema.ProductCartTable.Cols.PRODUCT_ID_COL + " INTEGER NOT NULL, "
                                + DbSchema.ProductCartTable.Cols.PRODUCT_NAME_COL + " TEXT NOT NULL, "
                                + DbSchema.ProductCartTable.Cols.PRODUCT_PRICE_COL + " DOUBLE NOT NULL, "
                                + DbSchema.ProductCartTable.Cols.PRODUCT_IMG_URL_COL + " TEXT NOT NULL, "
                                + DbSchema.ProductCartTable.Cols.PRODUCT_QUANTITY_COL + " INTEGER)");

//        sqLiteDatabase.execSQL("INSERT INTO product_carts (productId, name, price,imgUrl, quantity) values(1, 'Duy Anh 345' , 120.0,'https://cf.shopee.vn/file/beca50e46d2088fc5ad3c74aff5cc112', 1)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int oldVer, int newVer) {
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS product_carts" );
        onCreate(sqLiteDatabase);
    }
}
