package hanu.a2_2001040045.db;

public class DbSchema {
    public final class ProductCartTable {
        public static final String DB_NAME = "product_carts";

        public final class Cols{
            public static final String ID = "id";
            public static final String PRODUCT_ID_COL = "product_id";
            public static final String PRODUCT_NAME_COL = "product_name";
            public static final String PRODUCT_PRICE_COL = "product_price";
            public static final String PRODUCT_IMG_URL_COL = "product_img_url";
            public static final String PRODUCT_QUANTITY_COL = "product_quantity";

        }
    }
}
