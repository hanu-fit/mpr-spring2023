package hanu.a2_2001040045;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.SearchView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.os.HandlerCompat;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import hanu.a2_2001040150.adapters.ProductAdapter;
import hanu.a2_2001040150.models.Product;

public class MainActivity extends AppCompatActivity {
    List<Product> products = new ArrayList<>();

    ProductAdapter productAdapter;

    RecyclerView rcvProducts;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        searchProduct();

        rcvProducts = findViewById(R.id.rcvProducts);
        Handler handler = HandlerCompat.createAsync(Looper.getMainLooper());

        Constants.EXECUTOR_SERVICE.execute(() -> {
            String strJSON = loadJSON("https://hanu-congnv.github.io/mpr-cart-api/products.json");

            handler.post(() -> {
                if (strJSON == null){
                    Toast.makeText(MainActivity.this, "Failed to load products", Toast.LENGTH_SHORT).show();
                    return;
                }

                try {
                    JSONArray jsonArray = new JSONArray(strJSON);

                    for (int i =0; i < jsonArray.length(); i++){
                        JSONObject jsonObject = jsonArray.getJSONObject(i);
                        int productId = jsonObject.getInt("id");
                        String productName = jsonObject.getString("name");
                        double productPrice = jsonObject.getDouble("unitPrice");
                        String productImg = jsonObject.getString("thumbnail");

                        Product product = new Product(productId,productName,productPrice,productImg);
                        products.add(product);
                    }

                    productAdapter = new ProductAdapter(products);
                    rcvProducts.setLayoutManager(new GridLayoutManager(MainActivity.this, 2, LinearLayoutManager.VERTICAL, false));
                    rcvProducts.setAdapter(productAdapter);
                } catch (JSONException e) {
                    throw new RuntimeException(e);
                }
            });
        });


    }

    public String loadJSON(String link) {
        URL url;
        HttpURLConnection urlConnection;
        try {
            url = new URL(link);
            urlConnection = (HttpURLConnection) url.openConnection();
            urlConnection.connect();
            InputStream is = urlConnection.getInputStream();
            Scanner sc = new Scanner(is);
            StringBuilder result = new StringBuilder();
            String line;
            while(sc.hasNextLine()) {
                line = sc.nextLine();
                result.append(line);
            }
            return result.toString();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.activity_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.shoppingCart){
            Intent shoppingCartIntent = new Intent(MainActivity.this, ShoppingCart.class);
            startActivity(shoppingCartIntent);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void searchProduct() {
        SearchView search = findViewById(R.id.searchBar);

        search.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String s) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String word) {
                List <Product> result = new ArrayList<>();
                for (Product product: products) {
                    if (product.getName().toLowerCase().contains(word.toLowerCase())) {
                        result.add(product);
                    }
                }
                productAdapter = new ProductAdapter(result);
                rcvProducts.setAdapter(productAdapter);

                return false;
            }
        });
    }

}