package hanu.a2_2001040048.models;

public class Product {
    private int id;
    private String name;
    private int unitPrice;
    private String thumbnail;
    private String category;
    private int quantity;

    public Product() {
    }

    public Product(String name, int unitPrice, String thumbnail, String category, int quantity) {
        this.name = name;
        this.unitPrice = unitPrice;
        this.thumbnail = thumbnail;
        this.category = category;
        this.quantity = quantity;
    }

    public Product(int id, String name, int unitPrice, String thumbnail, String category, int quantity) {
        this.id = id;
        this.name = name;
        this.unitPrice = unitPrice;
        this.thumbnail = thumbnail;
        this.category = category;
        this.quantity = quantity;
    }

    @Override
    public String toString() {
        return "Product{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", unitPrice=" + unitPrice +
                ", thumbnail='" + thumbnail + '\'' +
                ", category='" + category + '\'' +
                ", quantity=" + quantity +
                '}';
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getUnitPrice() {
        return unitPrice;
    }

    public void setUnitPrice(int unitPrice) {
        this.unitPrice = unitPrice;
    }

    public String getThumbnail() {
        return thumbnail;
    }

    public void setThumbnail(String thumbnail) {
        this.thumbnail = thumbnail;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
}
