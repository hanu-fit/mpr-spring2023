package hanu.a2_2001040048.adapters;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.os.HandlerCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

import hanu.a2_2001040048.Constants;
import hanu.a2_2001040048.R;
import hanu.a2_2001040048.db.DbHelper;
import hanu.a2_2001040048.models.Product;

public class ProductAdapter extends RecyclerView.Adapter<ProductAdapter.ViewHolder> {

    private List<Product> productList;
    private Context context;
    private DbHelper dbHelper;

    public ProductAdapter(List<Product> productList, Context context) {
        this.productList = productList;
        this.context = context;
        this.dbHelper = new DbHelper(context);
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_product, parent, false);
        return new ViewHolder(itemView, dbHelper);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Product product = productList.get(position);
        holder.bind(product);
    }

    @Override
    public int getItemCount() {
        return productList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        private ImageView productThumbnail;
        private TextView productName;
        private TextView productPrice;
        private ImageButton addToCartButton;
        private DbHelper dbHelper;

        public ViewHolder(View itemView, DbHelper dbHelper) {
            super(itemView);
            this.dbHelper = dbHelper;
            productThumbnail = itemView.findViewById(R.id.product_thumbnail);
            productName = itemView.findViewById(R.id.product_name);
            productPrice = itemView.findViewById(R.id.product_price);
            addToCartButton = itemView.findViewById(R.id.add_to_cart_button);
        }

        public void bind(Product product) {
            DecimalFormat format = new DecimalFormat("#,###.##");
            String formattedPriceValue = format.format(product.getUnitPrice()) + " vnd";
            productName.setText(product.getName());
            productPrice.setText(formattedPriceValue);

            Glide.with(context)
                    .load(product.getThumbnail())
                    .into(productThumbnail);

            addToCartButton.setOnClickListener(v -> {
                dbHelper.addProduct(product);
            });
        }
    }

    public void updateData(List<Product> productList) {
        this.productList = productList;
        notifyDataSetChanged();
    }

    public void filter(String filter) {
        List<Product> filteredList = new ArrayList<>();
        for (Product product : productList) {
            if (product.getName().toLowerCase().contains(filter.toLowerCase())) {
                filteredList.add(product);
            }
        }
        updateData(filteredList);
    }
}

