package hanu.a2_2001040048;

import static hanu.a2_2001040048.Constants.BACKUP_JSON;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.os.HandlerCompat;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import hanu.a2_2001040048.adapters.ProductAdapter;
import hanu.a2_2001040048.db.DbHelper;
import hanu.a2_2001040048.models.Product;
import hanu.a2_2001040048.R;

public class MainActivity extends AppCompatActivity {
    public static final String URL = "https://hanu-congnv.github.io/mpr-cart-api/products.json";
    private ProductAdapter productAdapter;
    private TextView searchInputView;
    private ImageView searchBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        searchInputView = findViewById(R.id.search_input);
        searchBtn = findViewById(R.id.search_icon);

        RecyclerView rv = findViewById(R.id.product_list);
        rv.setLayoutManager(new GridLayoutManager(this,2));

        productAdapter = new ProductAdapter(allProducts(null), MainActivity.this);
        rv.setAdapter(productAdapter);

        loadProductsFromApi(this);

        ImageButton backButton = findViewById(R.id.toolbar_btn);
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, CartActivity.class);
                startActivity(intent);
            }
        });

        searchBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String filter = searchInputView.getText().toString();
                productAdapter.filter(filter);
            }
        });
    }

    private List<Product> allProducts(String filter) {
        DbHelper dbHelper = new DbHelper(this);
        List<Product> products = dbHelper.getAllProducts(filter);

        return products;
    }

    private void loadProductsFromApi(Context context) {

        Handler handler = HandlerCompat.createAsync(Looper.getMainLooper());

        Constants.executorService.execute(new Runnable() {
            @Override
            public void run() {
                String json = loadJSON(URL);

                handler.post(new Runnable() {
                    @Override
                    public void run() {
                        String data = BACKUP_JSON;
                        if (json == null) {
                            Toast.makeText(context, "Oops! Failed to load products json", Toast.LENGTH_LONG).show();
                        }
                        else data = json;
                        try {
                            List<Product> productList = new ArrayList<>();
                            JSONArray root = new JSONArray(data);
                            for (int i = 0; i < root.length(); i++) {
                                JSONObject productObject = root.getJSONObject(i);

                                String name = productObject.getString("name");
                                int price = productObject.getInt("unitPrice");
                                String thumbnail = productObject.getString("thumbnail");
                                String category = productObject.getString("category");

                                productList.add(new Product(name,price,thumbnail,category, 0));
                            }
                            productAdapter.updateData(productList);
                        }
                        catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }

                });
            }
        });
    }

    public String loadJSON(String link) {
        try {
            URL url = new URL(link);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            InputStream inputStream = connection.getInputStream();
            Scanner scanner = new Scanner(inputStream);
            StringBuilder builder = new StringBuilder();

            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                builder.append(line);
            }

            String json = builder.toString();
            Log.d("MainActivity", "JSON string: " + json); // add the log here
            return json;
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }}

