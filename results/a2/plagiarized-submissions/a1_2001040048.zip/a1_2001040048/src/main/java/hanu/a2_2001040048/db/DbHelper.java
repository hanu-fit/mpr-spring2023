package hanu.a2_2001040048.db;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

import hanu.a2_2001040048.models.Product;

public class DbHelper extends SQLiteOpenHelper {
    private static final String DB_NAME = "test";
    private static final int DB_VERSION = 1;
    private static final String PRODUCT_TABLE_NAME = "product";
    private static final String PRODUCT_ID = "id";
    private static final String PRODUCT_NAME = "name";
    private static final String PRODUCT_UNIT_PRICE = "unit_price";
    private static final String PRODUCT_THUMBNAIL = "thumbnail";
    private static final String PRODUCT_CATEGORY = "category";
    private static final String PRODUCT_QUANTITY = "quantity";

    private Context context;

    public DbHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
        this.context = context;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_PRODUCT_TABLE = "CREATE TABLE " + PRODUCT_TABLE_NAME +
                "(" +
                PRODUCT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
                PRODUCT_NAME + " TEXT," +
                PRODUCT_UNIT_PRICE + " INTEGER," +
                PRODUCT_THUMBNAIL + " TEXT," +
                PRODUCT_CATEGORY + " TEXT," +
                PRODUCT_QUANTITY + " INTEGER" +
                ")";
        db.execSQL(CREATE_PRODUCT_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + PRODUCT_TABLE_NAME);
        onCreate(db);
    }



    public List<Product> getAllProducts(String filter) {
        List<Product> productList = new ArrayList<>();

        String selectQuery = "SELECT * FROM " + PRODUCT_TABLE_NAME;

        if(filter != null && !filter.isEmpty()) {
            selectQuery += " WHERE " + PRODUCT_NAME + " LIKE '%" + filter + "%'";
        }

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);

        int indexId = cursor.getColumnIndex(PRODUCT_ID);
        int indexName = cursor.getColumnIndex(PRODUCT_NAME);
        int indexThumbnail = cursor.getColumnIndex(PRODUCT_THUMBNAIL);
        int indexCategory = cursor.getColumnIndex(PRODUCT_CATEGORY);
        int indexQuantity = cursor.getColumnIndex(PRODUCT_QUANTITY);
        int indexPrice = cursor.getColumnIndex(PRODUCT_UNIT_PRICE);

        while(cursor.moveToNext()) {
            int id = cursor.getInt(indexId);
            String name = cursor.getString(indexName);
            String thumbnail = cursor.getString(indexThumbnail);
            String category = cursor.getString(indexCategory);
            int quantity = cursor.getInt(indexQuantity);
            int price = cursor.getInt(indexPrice);

            Product product = new Product( id, name,price, thumbnail, category, quantity);
            productList.add(product);
        }

        cursor.close();
        db.close();

        return productList;
    }


    public void addProduct(Product product) {
        SQLiteDatabase db = this.getWritableDatabase();

        // Check if the product is already in the database
        Cursor cursor = db.rawQuery("SELECT * FROM " + PRODUCT_TABLE_NAME + " WHERE " + PRODUCT_NAME + " = ?", new String[]{product.getName()});
        if (cursor.moveToFirst()) {
            // If the product is already in the database, update its quantity
            int indexQuantity = cursor.getColumnIndex(PRODUCT_QUANTITY);
            int quantity = cursor.getInt(indexQuantity) + 1;
            ContentValues values = new ContentValues();
            values.put(PRODUCT_QUANTITY, quantity);
            db.update(PRODUCT_TABLE_NAME, values, PRODUCT_NAME + " = ?", new String[]{product.getName()});
        } else {
            // If the product is not in the database, add it with quantity 1
            ContentValues values = new ContentValues();
            values.put(PRODUCT_NAME, product.getName());
            values.put(PRODUCT_UNIT_PRICE, product.getUnitPrice());
            values.put(PRODUCT_THUMBNAIL, product.getThumbnail());
            values.put(PRODUCT_CATEGORY, product.getCategory());
            values.put(PRODUCT_QUANTITY, 1);
            db.insert(PRODUCT_TABLE_NAME, null, values);
        }

        cursor.close();
        db.close();
    }

    public void updateProductQuantity(Product product, int quantity) {
        SQLiteDatabase db = this.getWritableDatabase();

        // Check if the product is already in the database
        Cursor cursor = db.rawQuery("SELECT * FROM " + PRODUCT_TABLE_NAME + " WHERE " + PRODUCT_NAME + " = ?", new String[]{product.getName()});

        if (cursor.moveToFirst()) {
            // If the product is already in the database, update its quantity
            int indexQuantity = cursor.getColumnIndex(PRODUCT_QUANTITY);
            int currentQuantity = cursor.getInt(indexQuantity);
            if (quantity <= 0) {
                // If the quantity is 0 or negative, delete the product
                db.delete(PRODUCT_TABLE_NAME, PRODUCT_NAME + " = ?", new String[]{product.getName()});
            } else {
                // Otherwise, update the product quantity
                ContentValues values = new ContentValues();
                values.put(PRODUCT_QUANTITY, quantity);
                db.update(PRODUCT_TABLE_NAME, values, PRODUCT_NAME + " = ?", new String[]{product.getName()});
            }
        }

        cursor.close();
        db.close();
    }



}