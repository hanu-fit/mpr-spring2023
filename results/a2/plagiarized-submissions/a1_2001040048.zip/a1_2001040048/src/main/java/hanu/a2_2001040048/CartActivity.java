package hanu.a2_2001040048;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import hanu.a2_2001040048.adapters.CartAdapter;
import hanu.a2_2001040048.db.DbHelper;
import hanu.a2_2001040048.models.Product;

public class CartActivity extends AppCompatActivity {

    private TextView totalPriceTextView;
    private CartAdapter cartAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.cart_activity);

        // Get references to UI elements
        totalPriceTextView = findViewById(R.id.total_price);
        RecyclerView cartItemList = findViewById(R.id.cart_item_list);
        ImageView backButton = findViewById(R.id.toolbar_btn);

        // Initialize RecyclerView
        cartItemList.setLayoutManager(new LinearLayoutManager(this));

        // Set up CartAdapter with products and total price
        List<Product> products = getAllProducts();
        cartAdapter = new CartAdapter(products, this, totalPriceTextView);
        cartItemList.setAdapter(cartAdapter);

        // Set up click listener for back button
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(CartActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });
    }

    private List<Product> getAllProducts() {
        DbHelper dbHelper = new DbHelper(this);
        return dbHelper.getAllProducts(null);
    }
}

