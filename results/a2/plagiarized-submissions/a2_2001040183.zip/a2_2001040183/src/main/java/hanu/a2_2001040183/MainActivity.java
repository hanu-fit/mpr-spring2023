package hanu.a2_2001040183;

import static hanu.a2_2001040183.Constants.BACKUP_JSON;
import static hanu.a2_2001040183.Constants.URL;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.os.HandlerCompat;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.reflect.Type;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import hanu.a2_2001040183.adapters.ProductAdapter;
import hanu.a2_2001040183.db.DbHelper;
import hanu.a2_2001040183.models.Product;

public class MainActivity extends AppCompatActivity {
    public static final String URL = "https://hanu-congnv.github.io/mpr-cart-api/products.json";
    private ProductAdapter productAdapter;
    private TextView searchInputView;
    private ImageView searchBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        searchInputView = findViewById(R.id.search_input);
        searchBtn = findViewById(R.id.search_icon);

        RecyclerView rv = findViewById(R.id.product_list);
        rv.setLayoutManager(new GridLayoutManager(this, 2));

        productAdapter = new ProductAdapter(allProducts(null), MainActivity.this);


        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    URL url = new URL("https://hanu-congnv.github.io/mpr-cart-api/products.json");
                    HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                    connection.setRequestMethod("GET");
                    connection.connect();

                    InputStream inputStream = connection.getInputStream();
                    BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream, "UTF-8"));

                    StringBuilder sb = new StringBuilder();
                    String line;
                    while ((line = reader.readLine()) != null) {
                        sb.append(line);
                    }

                    String jsonString = sb.toString();

                    Gson gson = new Gson();
                    Type productListType = new TypeToken<List<Product>>(){}.getType();
                    List<Product> productList = gson.fromJson(jsonString, productListType);

                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            // create and set the adapter for the recycler view
                            productAdapter = new ProductAdapter(productList, MainActivity.this);
                            rv.setAdapter(productAdapter);
                        }
                    });

                    reader.close();
                    inputStream.close();
                    connection.disconnect();

                } catch (Exception e) {

                    e.printStackTrace();
                }
            }
        }).start();

        ImageButton backButton = findViewById(R.id.toolbar_btn);
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, CartActivity.class);
                startActivity(intent);
            }
        });

        searchBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String filter = searchInputView.getText().toString();
                Toast.makeText(MainActivity.this, searchInputView.getText(), Toast.LENGTH_SHORT).show();
                productAdapter.filter(filter);
            }
        });
    }

    private List<Product> allProducts(String filter) {
        DbHelper dbHelper = new DbHelper(this);
        List<Product> products = dbHelper.getAllProducts(filter);

        return products;
    }

}
