package hanu.a2_2001040183;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

import hanu.a2_2001040183.adapters.CartAdapter;
import hanu.a2_2001040183.adapters.ProductAdapter;
import hanu.a2_2001040183.db.DbHelper;
import hanu.a2_2001040183.models.Product;

public class CartActivity extends AppCompatActivity {
    TextView totalPrice;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.cart_activity);

        totalPrice = findViewById(R.id.total_price);

        List<Product> products = allProducts();
        RecyclerView rv = findViewById(R.id.cart_item_list);
        rv.setLayoutManager(new LinearLayoutManager(this));

        CartAdapter cartAdapter = new CartAdapter(products, CartActivity.this, totalPrice);
        rv.setAdapter(cartAdapter);

        ImageButton backButton = findViewById(R.id.toolbar_btn);
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent( CartActivity.this,MainActivity.class);
                startActivity(intent);
            }
        });
    }

    private List<Product> allProducts() {
        DbHelper dbHelper = new DbHelper(this);
       return dbHelper.getAllProducts(null);
    }
}
