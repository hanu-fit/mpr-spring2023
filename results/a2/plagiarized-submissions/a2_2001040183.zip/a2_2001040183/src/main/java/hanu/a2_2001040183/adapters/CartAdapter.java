package hanu.a2_2001040183.adapters;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.core.os.HandlerCompat;
import androidx.recyclerview.widget.RecyclerView;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.DecimalFormat;
import java.util.List;

import hanu.a2_2001040183.Constants;
import hanu.a2_2001040183.R;
import hanu.a2_2001040183.db.DbHelper;
import hanu.a2_2001040183.models.Product;

public class CartAdapter extends RecyclerView.Adapter<CartAdapter.ViewHolder> {
    private List<Product> productList;
    private Context context;

    private DbHelper dbHelper;

    private TextView totalPriceView;

    public CartAdapter(List<Product> productList, Context context, TextView totalPrice) {
        this.productList = productList;
        this.context = context;
        this.dbHelper = new DbHelper(context);
        this.totalPriceView = totalPrice;
    }

    @NonNull
    @Override
    public CartAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View itemView = inflater.inflate(R.layout.cart_item, parent,false);
        return new CartAdapter.ViewHolder(itemView, dbHelper);
    }

    @Override
    public void onBindViewHolder(@NonNull CartAdapter.ViewHolder holder, int position) {
        final Product product = productList.get(position);
        holder.bind(product,position);
    }

    @Override
    public int getItemCount() {
        return productList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        private ImageView productThumbnail;
        private TextView productName;
        private TextView productPrice;
        private ImageButton addBtn;
        private ImageButton removeBtn;
        private TextView productQuantity;
        private TextView sumPrice;

        private DbHelper dbHelper;

        public ViewHolder(@NonNull View itemView, DbHelper dbHelper) {
            super(itemView);

            this.dbHelper = dbHelper;
            productThumbnail = itemView.findViewById(R.id.product_thumbnail);
            productName = itemView.findViewById(R.id.product_name);
            productPrice = itemView.findViewById(R.id.product_price);
            productQuantity = itemView.findViewById(R.id.product_quantity);
            addBtn = itemView.findViewById(R.id.add_btn);
            removeBtn = itemView.findViewById(R.id.remove_btn);
            sumPrice = itemView.findViewById(R.id.sum_price);
        }

        public void bind(Product product, int position) {
            Handler handler = HandlerCompat.createAsync(Looper.getMainLooper());
            String formattedPriceValue = product.getUnitPrice() + " vnd";
            productName.setText(product.getName());
            productPrice.setText(formattedPriceValue);
            int quantity = product.getQuantity();
            productQuantity.setText(String.valueOf(quantity));
            int sum = product.getUnitPrice() * product.getQuantity();
            sumPrice.setText(String.valueOf(sum));

            Constants.executorService.execute(new Runnable() {
                @Override
                public void run() {
                    Bitmap bitmap = getBitmapFromUrl(product.getThumbnail());

                    handler.post(new Runnable() {
                        @Override
                        public void run() {
                            productThumbnail.setImageBitmap(bitmap);
                        }
                    });
                }
            });

            addBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Toast.makeText(view.getContext(), product.toString(), Toast.LENGTH_LONG).show();
                    dbHelper.updateProductQuantity(product, product.getQuantity() + 1);
                    product.setQuantity(product.getQuantity() + 1);
                    updateTotalPrice();
                    notifyItemChanged(position);
                }
            });

            removeBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    int quantity = product.getQuantity() - 1;
                    dbHelper.updateProductQuantity(product, quantity);
                    if (quantity > 0) {
                        product.setQuantity(product.getQuantity() - 1);
                        notifyItemChanged(getAdapterPosition());
                    }
                    else {
                        productList.remove(getAdapterPosition());
                        System.out.println(getAdapterPosition());
                        notifyItemRemoved(getAdapterPosition());
                    }
                    updateTotalPrice();
                }
            });
            updateTotalPrice();
        }

        public void updateTotalPrice() {
            int totalPrice = 0;
            for (Product product : productList) {
                totalPrice += product.getUnitPrice() * product.getQuantity();
            }
            totalPriceView.setText(String.valueOf(totalPrice) + " vnd");
        }

        public Bitmap getBitmapFromUrl(String urlString) {
            try {
                URL url = new URL(urlString);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.connect();
                InputStream inputStream = connection.getInputStream();
                Bitmap bitmap = BitmapFactory.decodeStream(inputStream);
                inputStream.close();
                return bitmap;
            } catch (Exception e) {
                e.printStackTrace();
                return null;
            }
        }
    }

}
