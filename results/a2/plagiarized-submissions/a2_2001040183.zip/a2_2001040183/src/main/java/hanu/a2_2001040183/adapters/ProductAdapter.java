package hanu.a2_2001040183.adapters;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.core.os.HandlerCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.squareup.picasso.Picasso;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

import hanu.a2_2001040183.Constants;
import hanu.a2_2001040183.R;
import hanu.a2_2001040183.db.DbHelper;
import hanu.a2_2001040183.models.Product;

public class ProductAdapter extends RecyclerView.Adapter<ProductAdapter.ViewHolder> {

    private List<Product> productList;
    private Context context;

    private DbHelper dbHelper;

    public ProductAdapter(List<Product> productList, Context context) {
        this.productList = productList;
        this.context = context;
        this.dbHelper = new DbHelper(context);
    }


    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_product, parent,false);
        System.out.println("This is me");
        return new ViewHolder(itemView, dbHelper);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        final Product product = productList.get(position);
        holder.bind(product,position);
    }

    @Override
    public int getItemCount() {
        return productList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        DecimalFormat format = new DecimalFormat("#,###.##");

        private ImageView productThumbnail;
        private TextView productName;
        private TextView productPrice;
        private ImageButton addToCartButton;

        private DbHelper dbHelper;

        public ViewHolder(@NonNull View itemView, DbHelper dbHelper) {
            super(itemView);

            this.dbHelper = dbHelper;
            productThumbnail = itemView.findViewById(R.id.product_thumbnail1);
            productName = itemView.findViewById(R.id.product_name);
            productPrice = itemView.findViewById(R.id.product_price);
            addToCartButton = itemView.findViewById(R.id.add_to_cart_button);
        }

        public void bind(Product product, int position) {
            String formattedPriceValue = format.format(product.getUnitPrice()) + " vnd";
            Picasso.get().load(product.getThumbnail()).into(productThumbnail);
            productName.setText(product.getName());
            productPrice.setText(formattedPriceValue);



            addToCartButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Toast.makeText(view.getContext(), product.getName(), Toast.LENGTH_LONG).show();
                    dbHelper.addProduct(product);
                }
            });
        }

        public Bitmap getBitmapFromUrl(String urlString) {
            try {
                URL url = new URL(urlString);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.connect();
                InputStream inputStream = connection.getInputStream();
                Bitmap bitmap = BitmapFactory.decodeStream(inputStream);
                inputStream.close();
                return bitmap;
            } catch (Exception e) {
                e.printStackTrace();
                return null;
            }
        }

    }
    public void updateData(List<Product> productList) {
        this.productList = productList;
        notifyDataSetChanged();
    }

    public void filter(String filter) {
        List<Product> filteredList = new ArrayList<>();

        for (Product product : productList) {
            if (product.getName().toLowerCase().contains(filter.toLowerCase())) {
                filteredList.add(product);
            }
        }

        updateData(filteredList);
    }

}
