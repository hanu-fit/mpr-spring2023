package hanu.a2_2001040183;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.widget.Toast;

import androidx.core.os.HandlerCompat;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import hanu.a2_2001040183.models.Product;

public class Constants {
    public static ExecutorService executorService = Executors.newFixedThreadPool(4);
    public static final String URL = "https://hanu-congnv.github.io/mpr-cart-api/products.json";

    public static final String BACKUP_JSON = "[\n" +
            "  {\n" +
            "    \"id\": 1,\n" +
            "    \"thumbnail\": \"https://cf.shopee.vn/file/beca50e46d2088fc5ad3c74aff5cc112\",\n" +
            "    \"name\": \"[Siêu HOT] Đèn Ngủ Chiếu Sao Tự Xoay 3D\",\n" +
            "    \"category\": \"lights\",\n" +
            "    \"unitPrice\": 169000\n" +
            "  },\n" +
            "  {\n" +
            "    \"id\": 2,\n" +
            "    \"thumbnail\": \"https://cf.shopee.vn/file/b0c4d1c4443fb7c2d9b97cd8681f444e\",\n" +
            "    \"name\": \"Đèn Ngủ 3D Led Nhiều Mẫu Hình Cực Đẹp - 3 màu (Được chọn hình)\",\n" +
            "    \"category\": \"lights\",\n" +
            "    \"unitPrice\": 55000\n" +
            "  },\n" +
            "  {\n" +
            "    \"id\": 3,\n" +
            "    \"thumbnail\": \"https://cf.shopee.vn/file/9333b4ea1c3df6693e9484487917b0c2\",\n" +
            "    \"name\": \"Đèn Ngủ Led Để Bàn Chân Gỗ Tự Nhiên [CMART.COM.VN]\",\n" +
            "    \"category\": \"lights\",\n" +
            "    \"unitPrice\": 99000\n" +
            "  },\n" +
            "  {\n" +
            "    \"id\": 4,\n" +
            "    \"thumbnail\": \"https://cf.shopee.vn/file/6df240e4782c481b88966ada56d92753\",\n" +
            "    \"name\": \"Đèn Ngủ 3D Led Nhiều Mẫu Hình Cực Đẹp - 3 màu- 001\",\n" +
            "    \"category\": \"lights\",\n" +
            "    \"unitPrice\": 55000\n" +
            "  },\n" +
            "  {\n" +
            "    \"id\": 5,\n" +
            "    \"thumbnail\": \"https://cf.shopee.vn/file/b4fb9f4fc4af2c52843a440134e907ef\",\n" +
            "    \"name\": \"Đèn ngủ silicon Trâu con dễ thương có điều khiển từ xa 16 màu Đồ trang trí Quà tặng đẹp [BH 1 đổi 1]\",\n" +
            "    \"category\": \"lights\",\n" +
            "    \"unitPrice\": 275000\n" +
            "  },\n" +
            "\n" +
            "  {\n" +
            "    \"id\": 6,\n" +
            "    \"thumbnail\": \"https://cf.shopee.vn/file/47fa76fecd88f10eee9768dbd301ed95\",\n" +
            "    \"name\": \"Đồng hồ điện tử nam nữ Sports S03 thể thao, mẫu mới tuyệt đẹp, full chức năng, chống nước tốt\",\n" +
            "    \"category\": \"watches\",\n" +
            "    \"unitPrice\": 23000\n" +
            "  },\n" +
            "  {\n" +
            "    \"id\": 7,\n" +
            "    \"thumbnail\": \"https://cf.shopee.vn/file/78e4450b07162a4e233620efbdeebae2\",\n" +
            "    \"name\": \"Đồng hồ thời trang nữ Gogey dây da êm tay, mặt tròn nhỏ xinh xắn, chống trày xước tốt\",\n" +
            "    \"category\": \"watches\",\n" +
            "    \"unitPrice\": 27000\n" +
            "  },\n" +
            "  {\n" +
            "    \"id\": 8,\n" +
            "    \"thumbnail\": \"https://cf.shopee.vn/file/42e07e90ee3fa5a7e65238145f50d8fd\",\n" +
            "    \"name\": \"Đồng Hồ Nam WWOOR 8826 Máy Nhật Dây Thép Mành Cao Cấp - Nhiều Màu\",\n" +
            "    \"category\": \"watches\",\n" +
            "    \"unitPrice\": 245500\n" +
            "  },\n" +
            "  {\n" +
            "    \"id\": 9,\n" +
            "    \"thumbnail\": \"https://cf.shopee.vn/file/ee5fdb8d1a095b9062d2021a4d790fda\",\n" +
            "    \"name\": \"Đồng Hồ Nữ \uD83D\uDC96\uD835\uDC05\uD835\uDC11\uD835\uDC04\uD835\uDC04 \uD835\uDC12\uD835\uDC07\uD835\uDC08\uD835\uDC0F\uD83D\uDC96 Chính Hãng ULZZANG 2702 Dây Lưới Nam Châm Cao Cấp.\",\n" +
            "    \"category\": \"watches\",\n" +
            "    \"unitPrice\": 79000\n" +
            "  },\n" +
            "  {\n" +
            "    \"id\": 10,\n" +
            "    \"thumbnail\": \"https://cf.shopee.vn/file/e6b47b0e53fdb23c2ec61736609d9a51\",\n" +
            "    \"name\": \"Vòng tay theo dõi sức khoẻ Mi Band 5 Xiaomi\",\n" +
            "    \"category\": \"watches\",\n" +
            "    \"unitPrice\": 569000\n" +
            "  },\n" +
            "\n" +
            "  {\n" +
            "    \"id\": 11,\n" +
            "    \"thumbnail\": \"https://cf.shopee.vn/file/ea069dc13e5f7ca7bfcc00c0c1daeda5\",\n" +
            "    \"name\": \"Mũ Bảo Hiểm Nửa Đầu 1/2 Nhiều Tem Siêu HOT - Hàng Cao Cấp\",\n" +
            "    \"category\": \"helmets\",\n" +
            "    \"unitPrice\": 99000\n" +
            "  },\n" +
            "  {\n" +
            "    \"id\": 12,\n" +
            "    \"thumbnail\": \"https://cf.shopee.vn/file/7969a15babb7f6703138615e33956eb1\",\n" +
            "    \"name\": \"Tai nghe phone 6/6s Zin - \uD83C\uDF81Tặng bao đựng + dây cuốn\uD83C\uDF81 - Bảo hành 12 tháng lỗi 1 đổi 1\",\n" +
            "    \"category\": \"earphones\",\n" +
            "    \"unitPrice\": 79000\n" +
            "  }\n" +
            "]";
    public static String loadJSON(String link) {
        try {
            URL url = new URL(link);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();

            InputStream inputStream = connection.getInputStream();
            Scanner scanner = new Scanner(inputStream);
            StringBuilder builder = new StringBuilder();

            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();

                builder.append(line);
            }
            return builder.toString();
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    public static List<Product> loadProductsFromApi(Context context) {
        List<Product> productList = new ArrayList<>();
        Handler handler = HandlerCompat.createAsync(Looper.getMainLooper());

        Constants.executorService.execute(new Runnable() {
            @Override
            public void run() {
                String json = Constants.loadJSON(URL);

                handler.post(new Runnable() {
                    @Override
                    public void run() {
                        if (json == null) {
//                            Toast.makeText(context, "Oops! Failed to load products json", Toast.LENGTH_LONG).show();
                        }
                        else {
                            try {
                                JSONArray root = new JSONArray(json);
                                for (int i = 0; i < root.length(); i++) {
                                    JSONObject productObject = root.getJSONObject(i);
                                    Product product = new Product();
                                    product.setName(productObject.getString("name"));
                                    Toast.makeText(context, "lomzom", Toast.LENGTH_SHORT).show();
                                    product.setUnitPrice(productObject.getInt("unitPrice"));
                                    product.setThumbnail(productObject.getString("thumbnail"));
                                    product.setCategory(productObject.getString("category"));

                                    productList.add(product);
                                }
                            }
                            catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }
                    }
                });
            }
        });
        return productList;
    }

}
