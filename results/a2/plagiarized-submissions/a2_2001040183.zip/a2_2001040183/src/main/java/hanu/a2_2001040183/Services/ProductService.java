package hanu.a2_2001040183.Services;

import java.util.List;

import hanu.a2_2001040183.models.Product;
import retrofit2.Call;
import retrofit2.http.GET;

public interface ProductService {
    @GET("products.json")
    Call<List<Product>> getAllProducts();
}
