package hanu.a2_2001040181.db;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class DbHelper extends SQLiteOpenHelper {
    private static final String DB_NAME = "a2_2001040181.db";
    public static final int DB_VERSION = 1;

    public DbHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        Log.i("db", "current db version: " + db.getVersion());
        // create table product
        db.execSQL("CREATE TABLE " + DbSchema.ProductTable.NAME + " (" +
                DbSchema.ProductTable.Column.ID + " INTEGER PRIMARY KEY, " +
                DbSchema.ProductTable.Column.THUMBNAIL + " TEXT NOT NULL, " +
                DbSchema.ProductTable.Column.NAME + " TEXT NOT NULL, " +
                DbSchema.ProductTable.Column.PRICE + " INTEGER NOT NULL)");

        // create table cartItem
        db.execSQL("CREATE TABLE " + DbSchema.CartItemTable.NAME + " (" +
                DbSchema.CartItemTable.Column.ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                DbSchema.CartItemTable.Column.PRODUCT_ID + " INTEGER NOT NULL, " +
                DbSchema.CartItemTable.Column.QUANTITY + " INTEGER NOT NULL)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.setVersion(newVersion);
        // drop tables (product and cartItem)
        db.execSQL("DROP TABLE IF EXISTS " + DbSchema.ProductTable.NAME);
        db.execSQL("DROP TABLE IF EXISTS " + DbSchema.CartItemTable.NAME);

        // create db again
        onCreate(db);
    }
}
