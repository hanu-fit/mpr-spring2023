package hanu.a2_2001040181;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Constants {
    public static final ExecutorService EXECUTOR_SERVICE = Executors.newFixedThreadPool(4);
    public static final String APILink ="https://hanu-congnv.github.io/mpr-cart-api/products.json";
}
