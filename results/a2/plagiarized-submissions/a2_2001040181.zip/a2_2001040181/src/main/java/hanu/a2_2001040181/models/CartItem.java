package hanu.a2_2001040181.models;

import androidx.annotation.NonNull;

import java.util.Collection;

public class CartItem {
    private int id;
    private int productId;
    private int quantity;

    public CartItem(int id, int productId, int quantity) {
        this.id = id;
        this.productId = productId;
        this.quantity = quantity;
    }

    public CartItem(int productId, int quantity) {
        this.productId = productId;
        this.quantity = quantity;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getProductId() {
        return productId;
    }

    public void setProductId(int productId) {
        this.productId = productId;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    @NonNull
    @Override
    public String toString() {
        return "CartItem{" +
                "id=" + id +
                ", productId=" + productId +
                ", quantity=" + quantity +
                '}';
    }

    public static CartItem findByProductId(int productId, Collection<CartItem> cartItems) {
        for (CartItem cartItem : cartItems) {
            if (cartItem.productId == productId) {
                return cartItem;
            }
        }
        return null;
    }
}
