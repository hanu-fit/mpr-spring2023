package hanu.a2_2001040181.models;

import androidx.annotation.NonNull;

import java.io.Serializable;
import java.util.Collection;

public class Product implements Serializable {
    private int id;
    private String thumbnail;
    private String name;
    private int unitPrice;

    public Product(int id, String thumbnail, String name, int unitPrice) {
        this.id = id;
        this.thumbnail = thumbnail;
        this.name = name;
        this.unitPrice = unitPrice;
    }


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getThumbnail() {
        return thumbnail;
    }

    public void setThumbnail(String thumbnail) {
        this.thumbnail = thumbnail;
    }

    public String getName() {
        return name;
    }

    public String getTrimName() {
        if (name.length() > 38) {
            return name.substring(0, 38) + "...";
        } else {
            return name;
        }
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getUnitPrice() {
        return unitPrice;
    }

    public String getFormattedUnitPrice() {
        return "đ " + unitPrice;
    }

    public void setUnitPrice(int unitPrice) {
        this.unitPrice = unitPrice;
    }

    @NonNull
    @Override
    public String toString() {
        return "Product{" +
                "id=" + id +
                ", thumbnail='" + thumbnail + '\'' +
                ", name='" + name + '\'' +
                ", unitPrice=" + unitPrice +
                '}';
    }

    public static Product findByCartItem(CartItem cartItem, Collection<Product> products) {
        for (Product product : products) {
            if (cartItem.getProductId() == product.getId()) {
                return product;
            }
        }
        return null;
    }
}
