package hanu.a2_2001040181;

import android.os.Bundle;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import hanu.a2_2001040181.adapters.CartItemAdapter;
import hanu.a2_2001040181.db.EntitiesManager;
import hanu.a2_2001040181.models.CartItem;
import hanu.a2_2001040181.models.Product;

public class CartActivity extends AppCompatActivity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.cart_activity);

        EntitiesManager entitiesManager = EntitiesManager.getInstance(this);
        List<Product> products = entitiesManager.getProductManager().all();
        List<CartItem> cartItems = entitiesManager.getCartManager().all();

        TextView footerTotalPriceTextView = findViewById(R.id.footer_price);

        RecyclerView rvProducts = findViewById(R.id.s2_rw);
        // set layout
        rvProducts.setLayoutManager(new LinearLayoutManager(CartActivity.this));
        // init adapter
        CartItemAdapter adapter = new CartItemAdapter(cartItems, products, footerTotalPriceTextView);
        // bind RecycleView with adapter
        rvProducts.setAdapter(adapter);

        ImageButton backBtn = findViewById(R.id.backBtn);
        backBtn.setOnClickListener(v -> finish());
    }
}
