package hanu.a2_2001040181.db;

import android.database.Cursor;
import android.database.CursorWrapper;

import java.util.ArrayList;
import java.util.List;

import hanu.a2_2001040181.models.Product;

public class ProductCursorWrapper extends CursorWrapper {
    public ProductCursorWrapper(Cursor cursor) {
        super(cursor);
    }

    public Product getProduct() {
        int idIndex = getColumnIndex(DbSchema.ProductTable.Column.ID);
        int thumbnailIndex = getColumnIndex(DbSchema.ProductTable.Column.THUMBNAIL);
        int nameIndex = getColumnIndex(DbSchema.ProductTable.Column.NAME);
        int priceIndex = getColumnIndex(DbSchema.ProductTable.Column.PRICE);

        int id = getInt(idIndex);
        String thumbnail = getString(thumbnailIndex);
        String name = getString(nameIndex);
        int price = getInt(priceIndex);

        return new Product(id, thumbnail, name, price);
    }

    public List<Product> getProducts() {
        List<Product> products = new ArrayList<>();
        moveToFirst();
        while (!isAfterLast()) {
            Product product = getProduct();
            products.add(product);
            moveToNext();
        }
        return products;
    }
}
