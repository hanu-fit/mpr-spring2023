package edu.hanu.mycart.adapters;

public class CartAdapter {
}
