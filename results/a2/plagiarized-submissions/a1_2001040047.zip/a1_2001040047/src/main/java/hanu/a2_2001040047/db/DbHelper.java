package hanu.a2_2001040047.db;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class DbHelper extends SQLiteOpenHelper {
    private static final String DB_NAME = "a2_2001040047.db";
    public static final int DB_VERSION = 1;

    public DbHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        Log.i("db", "current db version: " + db.getVersion());

        db.execSQL("CREATE TABLE " + DbSchema.Table.NAME + " (" +
                DbSchema.Table.Cols.ID + " INTEGER PRIMARY KEY, " +
                DbSchema.Table.Cols.THUMBNAIL + " TEXT NOT NULL, " +
                DbSchema.Table.Cols.NAME + " TEXT NOT NULL, " +
                DbSchema.Table.Cols.PRICE + " INTEGER NOT NULL)");

        db.execSQL("CREATE TABLE " + DbSchema.CartItemTable.NAME + " (" +
                DbSchema.CartItemTable.Cols.ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                DbSchema.CartItemTable.Cols.PRODUCT_ID + " INTEGER NOT NULL, " +
                DbSchema.CartItemTable.Cols.QUANTITY + " INTEGER NOT NULL)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.setVersion(newVersion);

        db.execSQL("DROP TABLE IF EXISTS " + DbSchema.Table.NAME);
        db.execSQL("DROP TABLE IF EXISTS " + DbSchema.CartItemTable.NAME);


        onCreate(db);
    }
}
