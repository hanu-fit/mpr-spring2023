package hanu.a2_2001040047.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import hanu.a2_2001040047.ImageDownloader;
import hanu.a2_2001040047.R;
import hanu.a2_2001040047.db.EntitiesManager;
import hanu.a2_2001040047.models.CartItem;
import hanu.a2_2001040047.models.Product;

public class CartItemAdapter extends RecyclerView.Adapter<CartItemAdapter.ProHolder> {

    protected class ProHolder extends RecyclerView.ViewHolder {
        public ProHolder(@NonNull View itemView) {
            super(itemView);
        }

        public void b (CartItem cartItem) {

            Product product = Product.findByCartItem(cartItem, products);


            ImageView imageView = itemView.findViewById(R.id.imageView);
            TextView nameView = itemView.findViewById(R.id.name2);
            TextView priceView = itemView.findViewById(R.id.single_price);
            ImageButton upBtn = itemView.findViewById(R.id.upBtn);
            ImageButton downBtn = itemView.findViewById(R.id.downBtn);
            TextView totalPrice = itemView.findViewById(R.id.total_price);
            TextView quantity = itemView.findViewById(R.id.quantity);


            ImageDownloader imageDown = new ImageDownloader(imageView);
            imageDown.execute(product.getThumbnail());

            nameView.setText(product.getTrimName());
            priceView.setText(product.getFormattedUnitPrice());

            int sum = singleProductSum(product);

            totalPrice.setText("đ " + sum);
            quantity.setText(cartItem.getQuantity() + "");


            EntitiesManager eManager = EntitiesManager.getInstance(itemView.getContext());
            Product finalProduct = product;
            upBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    cartItem.setQuantity(cartItem.getQuantity() + 1);
                    eManager.getCartManager().update(cartItem);


                    cartTotalPrice += finalProduct.getUnitPrice();
                    updateFooterUI();
                    CartItemAdapter.this.notifyDataSetChanged();
                }
            });

            downBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int quantity = cartItem.getQuantity();
                    if (quantity > 0) {

                        cartItem.setQuantity(quantity - 1);
                        eManager.getCartManager().update(cartItem);
                        if (cartItem.getQuantity() == 0) {
                            eManager.getCartManager().delete(cartItem.getId());
                            cartItems.remove(cartItem);
                            Toast.makeText(itemView.getContext(), "Removed "+product.getTrimName(), Toast.LENGTH_SHORT).show();
                        }

                        //handle footer total price
                        cartTotalPrice -= finalProduct.getUnitPrice();
                        updateFooterUI();
                        CartItemAdapter.this.notifyDataSetChanged();
                    }
                }
            });
        }
    }

    // dataset
    private final List<Product> products;
    private final List<CartItem> cartItems;

    private int cartTotalPrice;

    private TextView cartTotalPriceTextView;

    private int singleProductSum(Product product) {
        return product.getUnitPrice() * CartItem.findByProductId(product.getId(), cartItems).getQuantity();
    }

    private int calculate_cartTotalPrice() {
        int sum = 0;
        for (CartItem cartItem : cartItems) {
            sum += Product.findByCartItem(cartItem, products).getUnitPrice() * cartItem.getQuantity();
        }
        return sum;
    }

    private void updateFooterUI() {
        cartTotalPriceTextView.setText("đ " + cartTotalPrice);
    }

    public CartItemAdapter(List<CartItem> cartItems, List<Product> products, TextView cartTotalPriceTextView) {
        this.cartItems = cartItems;
        this.products = products;
        this.cartTotalPriceTextView = cartTotalPriceTextView;
        cartTotalPrice = calculate_cartTotalPrice();
        updateFooterUI();
    }

    @Override
    public int getItemCount() {
        return cartItems.size();
    }

    @NonNull
    @Override
    public ProHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        Context context = parent.getContext();


        LayoutInflater inflater = LayoutInflater.from(context);

        View itemView = inflater.inflate(R.layout.item_cart, parent, false);

        return new ProHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull ProHolder holder, int position) {
        CartItem cartItem = cartItems.get(position);


        holder.b(cartItem);
    }
}
