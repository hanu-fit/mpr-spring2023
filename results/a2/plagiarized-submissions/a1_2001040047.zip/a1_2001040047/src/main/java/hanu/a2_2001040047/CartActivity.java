package hanu.a2_2001040047;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import hanu.a2_2001040047.adapter.CartItemAdapter;
import hanu.a2_2001040047.db.EntitiesManager;
import hanu.a2_2001040047.models.CartItem;
import hanu.a2_2001040047.models.Product;

public class CartActivity extends AppCompatActivity {
    private CartItemAdapter adapter;
    private RecyclerView rwProducts;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.cart_activity);

        EntitiesManager enM = EntitiesManager.getInstance(this);
        List<Product> products = enM.getProductManager().all();
        List<CartItem> cartItems = enM.getCartManager().all();

        TextView TotalPrice = findViewById(R.id.footer_price);

        rwProducts = findViewById(R.id.s2_rw);

        rwProducts.setLayoutManager(new LinearLayoutManager(CartActivity.this));
        adapter = new CartItemAdapter(cartItems, products, TotalPrice);

        rwProducts.setAdapter(adapter);


    }
}
