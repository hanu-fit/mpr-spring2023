package hanu.a2_2001040047.db;

import android.database.Cursor;
import android.database.CursorWrapper;

import java.util.ArrayList;
import java.util.List;

import hanu.a2_2001040047.models.CartItem;

public class CartItemCursorWrapper extends CursorWrapper {
    public CartItemCursorWrapper(Cursor cursor) {
        super(cursor);
    }

    public CartItem getCart() {
        int idx = getColumnIndex(DbSchema.CartItemTable.Cols.ID);
        int proIdx = getColumnIndex(DbSchema.CartItemTable.Cols.PRODUCT_ID);
        int quanIdx = getColumnIndex(DbSchema.CartItemTable.Cols.QUANTITY);


        int id = getInt(idx);
        int productId = getInt(proIdx);
        int quantity = getInt(quanIdx);

        CartItem cart = new CartItem(id, productId,quantity);
        return cart;
    }

    public List<CartItem> getCarts() {
        List<CartItem> cartItems = new ArrayList<>();
        moveToFirst();
        while (!isAfterLast()) {
            CartItem cart = getCart();
            cartItems.add(cart);
            moveToNext();
        }
        return cartItems;
    }
}
