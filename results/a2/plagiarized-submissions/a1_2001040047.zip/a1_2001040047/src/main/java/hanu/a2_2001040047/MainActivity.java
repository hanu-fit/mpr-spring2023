package hanu.a2_2001040047;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.os.HandlerCompat;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import hanu.a2_2001040047.adapter.ProductAdapter;
import hanu.a2_2001040047.db.EntitiesManager;
import hanu.a2_2001040047.models.Product;

public class MainActivity extends AppCompatActivity {
    public static final int PRODUCT_ADDED = 1;

    private final Handler h = HandlerCompat.createAsync(Looper.getMainLooper());
    private EntitiesManager entM;


    private ProductAdapter adapter;
    private RecyclerView rw;

    // init dataset
    private List<Product> p = new ArrayList<>();
    private List<Product> dbProducts;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Constants.executor.execute(new Runnable() {
            @Override
            public void run() {
                String json = LoadJSON(Constants.APILink);
                h.post(new Runnable() {
                    @Override
                    public void run() {
                        if (json == null) {
                            Toast.makeText(MainActivity.this, "Oops, failed to connect!", Toast.LENGTH_SHORT).show();
                        } else {
                            try {
                                Toast.makeText(MainActivity.this, "Loading Items...", Toast.LENGTH_SHORT).show();
                                JSONArray root = new JSONArray(json);
                                for (int i = 0; i < root.length(); i++) {
                                    JSONObject jsonObj = (JSONObject) root.get(i);
                                    int id = jsonObj.getInt("id");
                                    String thumbnail = jsonObj.getString("thumbnail");
                                    String name = jsonObj.getString("name");
                                    int unitPrice = jsonObj.getInt("unitPrice");
                                    Product product = new Product(id, thumbnail, name, unitPrice);
                                    p.add(product);
                                }
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }

                        entM = EntitiesManager.getInstance(MainActivity.this);
                        entM.checkVersion();
                        dbProducts = entM.getProductManager().all();
                        if (!areProductsUpToDate()) {
                            rebuildDb();
                            dbProducts = entM.getProductManager().all();
                        }
                        p.clear();
                        p.addAll(dbProducts);
                        rw = findViewById(R.id.rwProducts);

                        GridLayoutManager gridLayoutManager = new GridLayoutManager(MainActivity.this, 2);
                        rw.setLayoutManager(gridLayoutManager);

                        adapter = new ProductAdapter(p);

                        rw.setAdapter(adapter);
                    }
                });
            }
        });

        TextView searchbarTextView = findViewById(R.id.searchbarTextView);
        ImageView searchBtn = findViewById(R.id.searchBtn);
        searchBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                search(searchbarTextView.getText().toString());
            }
        });

        ImageButton goToCart = findViewById(R.id.s1_go_to_cart);
        goToCart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, CartActivity.class);
//                intent.putExtra("products", (Serializable) products);
//                Bundle extras = intent.getExtras();
//                List<Product> list = (List<Product>) extras.get("products");
//                Log.i("KKKtuan", "ket qua: "+(list==products));
                startActivity(intent);
            }
        });
    }


    private boolean areProductsUpToDate() {
        if (p.size() != dbProducts.size()) {
            return false;
        }
        for (int i = 0; i < p.size(); i++) {
            Product p1 = p.get(i);
            Product p2 = dbProducts.get(i);
            if (p1.getId() != p2.getId()) {
                return false;
            }
        }
        return true;
    }

    private boolean rebuildDb() {
        entM.getProductManager().clear();
        entM.getCartManager().clear();
        for (Product product : p) {
            boolean result = entM.getProductManager().add(product);
            if (!result) {
                return false;
            }
        }
        return true;
    }

    private String LoadJSON(String link) {
        URL url;
        HttpURLConnection urlConnection = null;
        InputStream is = null;
        try {
            url = new URL(link);
            urlConnection = (HttpURLConnection) url.openConnection();
            urlConnection.connect();
            is = urlConnection.getInputStream();
            Scanner sc = new Scanner(is);
            StringBuilder r = new StringBuilder();
            String line;
            while (sc.hasNextLine()) {
                line = sc.nextLine();
                r.append(line);
            }
            return r.toString();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            // close resources
            if (urlConnection != null) {
                urlConnection.disconnect();
            }
            if (is != null) {
                try {
                    is.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        return null;
    }

    private void search(String content) {
        if (content.equals("")) {
            Toast.makeText(MainActivity.this, "Please type something...", Toast.LENGTH_SHORT).show();
        } else {
            reloadProductFromDb();

            Iterator<Product> i = p.iterator();
            while (i.hasNext()) {
                Product product = (Product) i.next();
                if (!product.getName().toLowerCase().contains(content.toLowerCase())) {
                    i.remove();
                }
            }
            adapter.notifyDataSetChanged();
            rw.setAdapter(adapter);

            // handle HomeBtn (for going back after searching)
            ImageButton homeBtn = findViewById(R.id.HomeBtn);
            homeBtn.setVisibility(View.VISIBLE);
            homeBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    reloadProductFromDb();
                    rw.setAdapter(adapter);
                    homeBtn.setVisibility(View.GONE);
                }
            });
        }
    }

    private void reloadProductFromDb() {
        p.clear();
        p.addAll(entM.getProductManager().all());
        adapter.notifyDataSetChanged();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == RESULT_OK && requestCode == PRODUCT_ADDED) {
            p.clear();
            p.addAll(entM.getProductManager().all());
            adapter.notifyDataSetChanged();
        }
    }
}