package hanu.a2_2001040047.db;

import android.database.Cursor;
import android.database.CursorWrapper;

import java.util.ArrayList;
import java.util.List;

import hanu.a2_2001040047.db.DbSchema;
import hanu.a2_2001040047.models.Product;

public class ProductCursorWrapper extends CursorWrapper {
    public ProductCursorWrapper(Cursor c) {
        super(c);
    }

    public Product getProduct() {
        int idIndex = getColumnIndex(DbSchema.Table.Cols.ID);
        int thumbnailIndex = getColumnIndex(DbSchema.Table.Cols.THUMBNAIL);
        int nameIndex = getColumnIndex(DbSchema.Table.Cols.NAME);
        int priceIndex = getColumnIndex(DbSchema.Table.Cols.PRICE);

        int id = getInt(idIndex);
        String thumbnail = getString(thumbnailIndex);
        String name = getString(nameIndex);
        int price = getInt(priceIndex);

        Product product = new Product(id, thumbnail, name, price);
        return product;
    }

    public List<Product> getProducts() {
        List<Product> products = new ArrayList<>();
        moveToFirst();
        while (!isAfterLast()) {
            Product product = getProduct();
            products.add(product);
            moveToNext();
        }
        return products;
    }
}
