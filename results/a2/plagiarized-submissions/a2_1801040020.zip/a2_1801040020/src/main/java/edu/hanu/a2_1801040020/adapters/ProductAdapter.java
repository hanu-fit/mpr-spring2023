package edu.hanu.a2_1801040020.adapters;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import javax.net.ssl.HttpsURLConnection;

import edu.hanu.a2_1801040020.R;
import edu.hanu.a2_1801040020.db.ProductManager;
import edu.hanu.a2_1801040020.models.Product;

/**
 * @author bangdc _ 1801040020
 * @overview: product adapter is to handle product in both main activity and cart activity (recognise by "Type" param in constructor)
 **/

public class ProductAdapter extends RecyclerView.Adapter<ProductAdapter.ProductHolder> implements Filterable {
    // Initiate ref

    Context context;
    ImageButton addBtn, removeBtn;
    ImageView image;
    EditText quantity;
    TextView name, price, totalPrice;
    ProductManager productManager;
    String type;
    int item_number, productPrice, total_unit, total_checkout = 0;
    boolean isSuccess = false;
    OnPriceChangeListener onPriceChangeListener;


//    Product Data including:
//    Product searchings
//    Product displaying-

    private List<Product> products;
    private List<Product> filtered_products;

    private List<Product> cartList;

    // NOTE View holder

    protected class ProductHolder extends RecyclerView.ViewHolder {

        public ProductHolder(@NonNull View itemView) {
            super(itemView);
        }
        public void bind(Product product) {


//          retrieve ref
            name = itemView.findViewById(R.id.tv_name);
            price = itemView.findViewById(R.id.tv_price);
            image = itemView.findViewById(R.id.plhld_img);

//          fetch info
            productPrice = Integer.parseInt(product.getPrice());


            switch (type) {
                case ("Home"):
                    addBtn = itemView.findViewById(R.id.cart_icon);
                    addBtn.setOnClickListener(view -> {

//                  get positoin
                        int position = productPositionCheck(product.getId(), cartList);
//                        handle if exists
                        if (position != -1) {
//                            get quantity
                            item_number = cartList.get(position).getQuantity();
                            isSuccess = changeQuantityNumber(product, item_number + 1);
                            if (isSuccess){
                                Toast.makeText(context, "Added", Toast.LENGTH_SHORT).show();
                            }
                        } else {
//                    add to cart list
                            product.setQuantity(1);
                            isSuccess = productManager.add(product);
                            if (isSuccess) {
                                cartList.add(product);
                                Toast.makeText(context, "Added to cart successfully!", Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
                    break;

                case ("Cart"):
                    removeBtn = itemView.findViewById(R.id.btn_remove);
                    addBtn = itemView.findViewById(R.id.btn_add);
                    totalPrice = itemView.findViewById(R.id.tv_total_price);
                    quantity = itemView.findViewById(R.id.et_quantity);

//                    get info
                    int item_number = product.getQuantity();
                    total_unit = item_number * productPrice;

//                    set quantity
                    quantity.setText(item_number + "");
                    // set price text
                    totalPrice.setText(total_unit + "");


// handle remove button
                    removeBtn.setOnClickListener(view -> {
                        getTotalCheckout(-total_checkout); //reset totalCheckout
                        if (item_number == 1) {
                            int position = productPositionCheck(product.getId(),products);
                            Toast.makeText(context, "removing", Toast.LENGTH_SHORT).show();
                            isSuccess = productManager.delete(product.getId());
                            if (isSuccess) {
                                products.remove(position);
                                notifyDataSetChanged();
                            }
                            if (products.isEmpty()){
                                Toast.makeText(context, "Cart is empty!", Toast.LENGTH_SHORT).show();
                            }
                            return;
                        }

                        product.setQuantity(item_number - 1);
                        isSuccess = productManager.update(product);
                        notifyDataSetChanged();
                    });

//                    handle add item button
                    addBtn.setOnClickListener(view -> {
                        getTotalCheckout(-total_checkout); // reset totalCheckout
                        isSuccess = changeQuantityNumber(product, item_number + 1);
                        if (isSuccess) notifyDataSetChanged();
                    });

//                  change total checkout
                    getTotalCheckout(total_unit);
                    break;

                default:
                    break;
            }

//            set info
            name.setText(product.getName());
            price.setText(productPrice + "");

//            set image
            String link = product.getThumbnail();
            new LoadImage(image, context).execute(link);

        }
    }

    // constructor
    public ProductAdapter(List<Product> products, Context context, String type) {
        this.products = products;
        this.filtered_products = products;  // set default filter list
        this.context = context;
        this.type = type;
//        data set
        productManager = ProductManager.getInstance(context);
        this.cartList = productManager.all();

//        set data transfer back
        if (type.equals("Cart")) {
            try {
                this.onPriceChangeListener = ((OnPriceChangeListener) context);
            } catch (ClassCastException e) {
                throw new ClassCastException(e.getMessage());
            }
        }
    }

    @NonNull
    @Override
    public ProductHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View itemView = null;

        switch (type) {
            case "Home":
                itemView = inflater.inflate(R.layout.product_item, parent, false);
                break;
            case "Cart":
                itemView = inflater.inflate(R.layout.product_cart, parent, false);
                break;
        }

        return new ProductHolder(itemView);
    }


    @Override
    public void onBindViewHolder(@NonNull ProductHolder holder, int position) {
//        get product at position
        Product product = filtered_products.get(position);

//      bind to view
        holder.bind(product);
    }

    @Override
    public int getItemCount() {
        return filtered_products.size();
    }

    /*
    Function
    TODO
    Loadimage - OK
    prod postion - OK
    gettotscheckout -OK
    change quan - OK
    get filter - OK

     */
    //    load image
    private class LoadImage extends AsyncTask<String, Integer, Bitmap> {

        ImageView imgView;
        Context context;

        public LoadImage(ImageView imgView, Context context) {
            this.imgView = imgView;
            this.context = context;
        }

        @Override
        protected Bitmap doInBackground(String... urls) {
            try {
                URL url = new URL(urls[0]);
                HttpsURLConnection connection = (HttpsURLConnection) url.openConnection();
                connection.setDoInput(true);
                connection.connect();
                InputStream in = connection.getInputStream();
                Bitmap image = BitmapFactory.decodeStream(in);
                return image;

            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Bitmap bitmap) {
            super.onPostExecute(bitmap);
            imgView.setImageBitmap(bitmap);
        }
    }

    // check product in cart
    public int productPositionCheck(long id, List<Product> products) {
        //set position as not found
        int position = -1;
        int size = products.size();

        if (size != 0) {
            for (position = 0; position < size; position++) {
                if (products.get(position).getId() == id) break; // exist -> break
            }
            if (position == size) position = -1; // not exist
        }

        return position;
    }

    public interface OnPriceChangeListener {
        void onPriceChange(int price);
    }

    //calculations
    private void getTotalCheckout(int totalUnit) {
        total_checkout += totalUnit;
        onPriceChangeListener.onPriceChange(total_checkout);
    }

    // change quan number
    private boolean changeQuantityNumber(Product product, int quantity) {
        product.setQuantity(quantity);
        return productManager.update(product);
    }

// NOTE: TODO search func - OK
    @Override
    public Filter getFilter() {
        return new Filter() {
            @Override
            protected FilterResults performFiltering(CharSequence charSequence) {

                String query = charSequence.toString();

                if (query.isEmpty()){
                    filtered_products = products;
                } else{
                    filtered_products = new ArrayList<>();
                    for (Product product : products) {
                        if(product.getName().toLowerCase().contains(query.toLowerCase()))
                            filtered_products.add(product);
                    }
                }

                FilterResults results = new FilterResults();
                results.values = filtered_products;

                return results;
            }

            @Override
            protected void publishResults(CharSequence charSequence, FilterResults filterResults) {
                filtered_products = (List<Product>) filterResults.values;
                if (filtered_products.isEmpty())
                    Toast.makeText(context, "Product with the matching search key not found. Please try again.", Toast.LENGTH_SHORT).show();
                notifyDataSetChanged();
            }
        };
    }


//=========================== END =============================
}

