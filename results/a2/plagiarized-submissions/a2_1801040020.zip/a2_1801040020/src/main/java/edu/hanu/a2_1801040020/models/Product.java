package edu.hanu.a2_1801040020.models;

import java.io.Serializable;

public class Product implements Serializable {

    private long id, number;
    private int quantity;
    private String name, thumbnail, price;

    public Product(long id, String name, String thumbnail, String price) {
        this.id = id;
        this.thumbnail = thumbnail;
        this.name = name;
        this.price = price;
    }

    public Product(long number, long id, String name, String thumbnail, String price, int quantity) {
        this.id = id;
        this.thumbnail = thumbnail;
        this.name = name;
        this.quantity = quantity;
        this.price = price;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public long getNumber() {
        return number;
    }

    public void setNumber(long number) {
        this.number = number;
    }

    public String getThumbnail() {
        return thumbnail;
    }

    public void setThumbnail(String thumbnail) {
        this.thumbnail = thumbnail;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    // tostring() here

    @Override
    public String toString() {
        return "Product{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", thumbnail='" + thumbnail + '\'' +
                ", price='" + price + '\'' +
                ", quantity='" + quantity + '\'' +
                '}';
    }
}
