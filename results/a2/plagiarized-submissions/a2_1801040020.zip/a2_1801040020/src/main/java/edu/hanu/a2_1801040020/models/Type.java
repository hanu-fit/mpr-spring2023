package edu.hanu.a2_1801040020.models;

public class Type {
    public static final String CART = "Cart";
    public static final String HOME = "Home";
}
