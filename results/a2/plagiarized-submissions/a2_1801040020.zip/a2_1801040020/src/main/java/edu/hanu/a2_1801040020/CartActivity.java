package edu.hanu.a2_1801040020;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

import edu.hanu.a2_1801040020.adapters.ProductAdapter;
import edu.hanu.a2_1801040020.db.ProductManager;
import edu.hanu.a2_1801040020.models.Product;
import edu.hanu.a2_1801040020.models.Type;

public class CartActivity extends AppCompatActivity implements ProductAdapter.OnPriceChangeListener {

    //    ref
    LinearLayout empty_notice, checkout_btn;
    RecyclerView rv_cart;
    ProductAdapter productAdapter;
    ProductManager productManager;
    TextView tv_cart_total;
    List<Product> cart_list;
    MenuItem redirect_btn, search_btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cart);

//        get ref
        empty_notice = findViewById(R.id.ll_empty);
        rv_cart = findViewById(R.id.rv_cart);
        tv_cart_total = findViewById(R.id.tv_cart_total);
        checkout_btn = findViewById(R.id.ll_checkout);

//        get list
        productManager = ProductManager.getInstance(CartActivity.this);
        cart_list = productManager.all();

//        if cart_list has item, hide empty notice
        if (!cart_list.isEmpty()) {
            empty_notice.setVisibility(View.GONE);

            // display item
            productAdapter = new ProductAdapter(cart_list, CartActivity.this, Type.CART);
            rv_cart.setLayoutManager(new LinearLayoutManager(CartActivity.this));
            rv_cart.setAdapter(productAdapter);


//            check out btn
            checkout_btn.setOnClickListener(view -> {
                if (productManager.clean()) {
                    Toast.makeText(CartActivity.this, "Ordered successfully !", Toast.LENGTH_SHORT).show();
                    changeAct(MainActivity.class);
                }
            });

        }


    }



    @Override
    public void onBackPressed() {
        super.onBackPressed();
//        reset data when back
        changeAct(MainActivity.class);
    }

    @Override
    public void onPriceChange(int price) {
        tv_cart_total.setText(price + "");
    }

    /*
    MENU
    TODO:
    create option - ok
    select - ok
    prep - ok
    change act - ok
     */
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);
        search_btn = menu.findItem(R.id.btn_search);
        search_btn.setVisible(false); // hide search btn

        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        super.onOptionsItemSelected(item);

        changeAct(MainActivity.class);

        return false;
    }

    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {

        redirect_btn = menu.findItem(R.id.btn_redirect);
//      change button
        redirect_btn.setIcon(R.drawable.ic_home)
                .setTitle(R.string.menu_home);

        return super.onPrepareOptionsMenu(menu);
    }



    public void changeAct(Class activity) {
        Intent intent = new Intent(getApplicationContext(), activity);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
    }


}