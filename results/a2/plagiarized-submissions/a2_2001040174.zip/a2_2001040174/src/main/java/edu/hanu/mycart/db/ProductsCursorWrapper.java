package edu.hanu.mycart.db;

import android.database.Cursor;
import android.database.CursorWrapper;

import java.util.ArrayList;
import java.util.List;

import edu.hanu.mycart.models.Product;

public class ProductsCursorWrapper extends CursorWrapper {

    public ProductsCursorWrapper(Cursor cursor) {
        super(cursor);
    }

    public List<Product> getProducts() {
        List<Product> products = new ArrayList<>();

        moveToFirst();

        for(moveToFirst(); !isAfterLast(); moveToNext()) {
            products.add(getProduct());
        }
        return products;
    }

    public Product getProduct() {
        int numIndex = getColumnIndex(DbSchema.PRODUCT_TABLE.columns.NUM);
        int idIndex = getColumnIndex(DbSchema.PRODUCT_TABLE.columns.ID);
        int nameIndex = getColumnIndex(DbSchema.PRODUCT_TABLE.columns.NAME);
        int thumbnailIndex = getColumnIndex(DbSchema.PRODUCT_TABLE.columns.THUMBNAIL);
        int priceIndex = getColumnIndex(DbSchema.PRODUCT_TABLE.columns.PRICE);
        int amountIndex = getColumnIndex(DbSchema.PRODUCT_TABLE.columns.AMOUNT);

        long num = -1;
        if (!isNull(numIndex)) {
            num = getInt(numIndex);
        }

        long id = -1;
        if (!isNull(idIndex)) {
            id = getInt(idIndex);
        }

        String name = "";
        if (!isNull(nameIndex)) {
            name = getString(nameIndex);
        }

        String thumbnail = "";
        if (!isNull(thumbnailIndex)) {
            thumbnail = getString(thumbnailIndex);
        }

        String price = "";
        if (!isNull(priceIndex)) {
            price = getString(priceIndex);
        }

        int amount = -1;
        if (!isNull(amountIndex)) {
            amount = getInt(amountIndex);
        }

        return new Product(num, id, name, thumbnail, price, amount);
    }
}
