package edu.hanu.mycart.models;

public class Type {
    public static final String HOME = "Home";
    public static final String CART = "Cart";
}
