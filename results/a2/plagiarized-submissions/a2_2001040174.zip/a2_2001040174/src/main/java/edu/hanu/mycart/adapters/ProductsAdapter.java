package edu.hanu.mycart.adapters;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import javax.net.ssl.HttpsURLConnection;

import edu.hanu.mycart.R;
import edu.hanu.mycart.db.ProductsManager;
import edu.hanu.mycart.models.Product;

public class ProductsAdapter extends RecyclerView.Adapter<ProductsAdapter.ProductHolder> implements Filterable {

    // init ref
    Context prod_context;
    TextView prod_name, prod_price, totalPrice;
    ImageButton addBtn, removeBtn;
    ImageView prod_image;
    EditText prod_amount;
    String prod_type;
    ProductsManager productsManager;
    boolean isSuccess = false;
    int amount, price, totalAmount, sum = 0;
    OnPriceChangeListener onPriceChangeListener;

    //dataset
    private List<Product> products;
    private List<Product> filteredProducts;
    private List<Product> cartList;

    //view holder
    protected class ProductHolder extends RecyclerView.ViewHolder {
        public ProductHolder(@NonNull View itemView) {
            super(itemView);
        }

        public void bind(Product product) {

//            get info
            // Parse the price string to an integer
            int price = Integer.parseInt(product.getPrice());

// Get references to the views in the item layout
            TextView prod_name = itemView.findViewById(R.id.tv_name);
            TextView prod_price = itemView.findViewById(R.id.tv_price);
            ImageView prod_image = itemView.findViewById(R.id.iv_img);

// Depending on the type of product, show the appropriate buttons and views
            switch (prod_type) {
                case ("Home"):
                    ImageButton addBtn = itemView.findViewById(R.id.ib_cart_ic);

                    // Set a click listener for the add button
                    addBtn.setOnClickListener(view -> {
                        // Check if the product is already in the cart
                        int position = prodPos(product.getId(), cartList);

                        // If the product is already in the cart, increment its quantity
                        if (position != -1) {
                            int amount = cartList.get(position).getAmount();
                            boolean isSuccess = changeQuantity(product, amount + 1);
                            if (isSuccess) {
                                Toast.makeText(prod_context, "Added", Toast.LENGTH_SHORT).show();
                            }
                        } else {
                            // If the product is not in the cart, add it with quantity of 1
                            product.setAmount(1);
                            boolean isSuccess = productsManager.add(product);
                            if (isSuccess) {
                                cartList.add(product);
                                Toast.makeText(prod_context, "Added to cart successfully!", Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
                    break;
                case ("Cart"):

                addBtn = itemView.findViewById(R.id.btn_add);
                    Button removeBtn = itemView.findViewById(R.id.btn_remove);
                    EditText prod_amount = itemView.findViewById(R.id.et_quantity);
                    TextView totalPrice = itemView.findViewById(R.id.tv_total_price);
//                    get info
                    int quantity = product.getAmount();
                    double totalAmount = quantity * Double.parseDouble(product.getPrice());

// Set the values of the quantity and total price views
                    prod_amount.setText(String.valueOf(quantity));
                    totalPrice.setText(String.format(Locale.getDefault(), "%.2f", totalAmount));

// Handle the add and remove buttons
                    addBtn.setOnClickListener(v -> {
                        getTotalCheckout(-sum); // Reset the sum
                        boolean updated = changeQuantity(product, quantity + 1);
                        if (updated) {
                            notifyDataSetChanged();
                        }
                    });

                    removeBtn.setOnClickListener(v -> {
                        getTotalCheckout(-sum); // Reset the sum
                        if (quantity == 1) {
                            int position = prodPos(product.getId(), products);
                            Toast.makeText(prod_context, "Removing", Toast.LENGTH_SHORT).show();
                            boolean deleted = productsManager.delete(product.getId());
                            if (deleted) {
                                products.remove(position);
                                notifyDataSetChanged();
                            }
                            if (products.isEmpty()) {
                                Toast.makeText(prod_context, "Cart is empty!", Toast.LENGTH_SHORT).show();
                            }
                            return;
                        }
                        product.setAmount(quantity - 1);
                        boolean updated = productsManager.update(product);
                        if (updated) {
                            notifyDataSetChanged();
                        }
                    });
//                  change total checkout
                    getTotalCheckout((int) totalAmount);
                    break;
                default:
                    break;
            }

//            set info
            prod_name.setText(product.getName());
            prod_price.setText(price +  " ");

//            set prod_image
            String url = product.getThumbnail();
            new LoadImage(prod_image, prod_context).execute(url);

        }
    }

    // constructor
    public ProductsAdapter(List<Product> products, Context prod_context, String prod_type) {
        this.products = products;
        this.filteredProducts = products;  // set default filter list
        this.prod_context = prod_context;
        this.prod_type = prod_type;
//        data set
        productsManager = ProductsManager.getInstance(prod_context);
        this.cartList = productsManager.getAll();

//        set data transfer back
        if (prod_type.equals("Cart")) {
            try {
                this.onPriceChangeListener = ((OnPriceChangeListener) prod_context);
            } catch (ClassCastException e) {
                throw new ClassCastException(e.getMessage());
            }
        }
    }

    @NonNull
    @Override
    public ProductHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View view = null;

        switch (prod_type) {
            case "Home":
                view = inflater.inflate(R.layout.product_item, parent, false);
                break;
            case "Cart":
                view = inflater.inflate(R.layout.product_cart, parent, false);
                break;
        }

        return new ProductHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ProductHolder holder, int position) {
//        get product at position
        Product product = filteredProducts.get(position);

//      bind to view
        holder.bind(product);
    }

    @Override
    public int getItemCount() {
        return filteredProducts.size();
    }

//    ==================== FUNCTION =======================

    //    load prod_image
    private class LoadImage extends AsyncTask<String, Integer, Bitmap> {

        ImageView imgView;
        Context prod_context;

        public LoadImage(ImageView imgView, Context prod_context) {
            this.imgView = imgView;
            this.prod_context = prod_context;
        }

        @Override
        protected Bitmap doInBackground(String... urls) {
            try {
                URL url = new URL(urls[0]);
                HttpsURLConnection connection = (HttpsURLConnection) url.openConnection();
                connection.setDoInput(true);
                connection.connect();
                InputStream in = connection.getInputStream();
                Bitmap prod_image = BitmapFactory.decodeStream(in);
                return prod_image;

            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Bitmap bitmap) {
            super.onPostExecute(bitmap);
            imgView.setImageBitmap(bitmap);
        }
    }

    // check product in cart
    public int prodPos(long id, List<Product> products) {
        int position = -1; // position not found
        int size = products.size();

        if (size != 0) {
            for (position = 0; position < size; position++) {
                if (products.get(position).getId() == id) break; // exist -> break
            }
            if (position == size) position = -1; // not exist
        }

        return position;
    }

    // onPriceChangeListener
    public interface OnPriceChangeListener {
        void onPriceChange(int prod_price);
    }

    // calculate
    private void getTotalCheckout(int totalAmount) {
        sum += totalAmount;

//        return sum to activity
        onPriceChangeListener.onPriceChange(sum);

    }

    // change prod_amount
    private boolean changeQuantity(Product product, int prod_amount) {
        product.setAmount(prod_amount);
        return productsManager.update(product);
    }

//    Search function TODO implement search function and

    @Override
    public Filter getFilter() {
        return new Filter() {
            @Override
            protected FilterResults performFiltering(CharSequence charSequence) {

                String query = charSequence.toString();

                if (query.isEmpty()){
                    filteredProducts = products;
                } else{
                    filteredProducts = new ArrayList<>();
                    for (Product product : products) {
                        if(product.getName().toLowerCase().contains(query.toLowerCase())) filteredProducts.add(product);
                    }
                }

                FilterResults results = new FilterResults();
                results.values = filteredProducts;

                return results;
            }

            @Override
            protected void publishResults(CharSequence charSequence, FilterResults filterResults) {
                filteredProducts = (List<Product>) filterResults.values;

                if (filteredProducts.isEmpty()) Toast.makeText(prod_context, "No product match :( Please check again", Toast.LENGTH_SHORT).show();

                notifyDataSetChanged();
            }
        };
    }


}

