package edu.hanu.mycart.db;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;

import java.util.ArrayList;
import java.util.List;

import edu.hanu.mycart.models.Product;

public class ProductsManager {

    //    init
    private final DbHelper dbHelper;
    private final SQLiteDatabase db;
    List<Product> products;

    private static SQLiteStatement statement;
    // insert a new row
    private static final String INSERT_QUERY = String.format("INSERT INTO %s (id, name, image, price, quantity) VALUES (?, ?, ?, ?, ?)",
            DbSchema.PRODUCT_TABLE.TABLE);

    //  update the quantity
    private static final String UPDATE_QUERY = String.format("UPDATE %s SET amount = ? WHERE id = ?",
            DbSchema.PRODUCT_TABLE.TABLE);

    // Define values
    private static ProductsManager values;

    // Constructor
    public ProductsManager(Context context) {
        this.dbHelper = new DbHelper(context);
        this.db = dbHelper.getWritableDatabase();
        this.products = new ArrayList<>();
    }

    // Get values
    public static ProductsManager getInstance(Context context) {
        if (values == null) {
            values = new ProductsManager(context);
        }
        return values;
    }


    //    get all prod
    public List<Product> getAll() {
        Cursor results = db.rawQuery("SELECT * FROM cart", null);
        ProductsCursorWrapper cursor = new ProductsCursorWrapper(results);

        return cursor.getProducts();
    }

    //  add prod
    public boolean add(Product product) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("id", product.getId());
        values.put("name", product.getName());
        values.put("image", product.getThumbnail());
        values.put("price", product.getPrice());
        values.put("amount", product.getAmount());

        long rowId = db.insert(DbSchema.PRODUCT_TABLE.TABLE, null, values);
        if (rowId > 0) {
            product.setNum(rowId);
            return true;
        } else {
            return false;
        }
    }

    //    update amount
    public boolean update(Product product) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("amount", product.getAmount());

        String whereClause = "id = ?";
        String[] whereArgs = new String[]{String.valueOf(product.getId())};

        int AffectedRows = db.update(DbSchema.PRODUCT_TABLE.TABLE, values, whereClause, whereArgs);

        return AffectedRows == 1;
    }

    //    delete 1 product
    public boolean delete(long id) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();

        String whereClause = "id = ?";
        String[] whereArgs = new String[]{String.valueOf(id)};

        int numAffectedRows = db.delete(DbSchema.PRODUCT_TABLE.TABLE, whereClause, whereArgs);
        return numAffectedRows == 1;
    }
//    delete all product
    public boolean clearAll() {
        SQLiteDatabase db = dbHelper.getWritableDatabase();

        int numAffectedRows = db.delete(DbSchema.PRODUCT_TABLE.TABLE, null, null);

        return numAffectedRows > 0;
    }
}
