package edu.hanu.mycart.db;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class DbHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "PRODUCT_TABLE";
    private static final int DATABASE_VERSION = 1;

    public DbHelper(@Nullable Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTableQuery =
                "CREATE TABLE IF NOT EXISTS cart (" +
                        "number INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        "id INTEGER NOT NULL, " +
                        "name TEXT NOT NULL, " +
                        "price INTEGER NOT NULL, " +
                        "image TEXT NOT NULL, " +
                        "amount INTEGER NOT NULL" +
                        ");";
        db.execSQL(createTableQuery);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS cart;");
        onCreate(db);
    }
}

