package edu.hanu.mycart;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

import edu.hanu.mycart.adapters.ProductsAdapter;
import edu.hanu.mycart.db.ProductsManager;
import edu.hanu.mycart.models.Product;
import edu.hanu.mycart.models.Type;

public class CartActivities extends AppCompatActivity implements ProductsAdapter.OnPriceChangeListener {

    LinearLayout emptyNotice, checkoutBtn;
    RecyclerView rvCart;
    ProductsAdapter productsAdapter;
    ProductsManager productsManager;
    TextView tvCartTotal;
    List<Product> cartList;
    MenuItem btnRedirect, btnSearch;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cart);

        emptyNotice = findViewById(R.id.ll_empty);
        rvCart = findViewById(R.id.rv_cart);
        tvCartTotal = findViewById(R.id.tv_cart_total);
        checkoutBtn = findViewById(R.id.ll_checkout);

        productsManager = ProductsManager.getInstance(CartActivities.this);
        cartList = productsManager.getAll();

        if (!cartList.isEmpty()) {
            emptyNotice.setVisibility(View.GONE);

            productsAdapter = new ProductsAdapter(cartList, CartActivities.this, Type.CART);

            rvCart.setLayoutManager(new LinearLayoutManager(CartActivities.this));

            rvCart.setAdapter(productsAdapter);

            checkoutBtn.setOnClickListener(view -> {
                if (productsManager.clearAll()) {
                    Toast.makeText(CartActivities.this, "You have successfully ordered !!!", Toast.LENGTH_SHORT).show();
                    changeAct(MainActivites.class);
                }
            });

        }


    }


    public void onPriceChange(int price) {
        tvCartTotal.setText(price + "");
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
//        reset data when back
        changeAct(MainActivites.class);
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);
        btnSearch = menu.findItem(R.id.btn_search);
        btnSearch.setVisible(false); // hide search btn

        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {

        btnRedirect = menu.findItem(R.id.btn_redirect);
//      change button
        btnRedirect.setIcon(R.drawable.ic_home)
                .setTitle(R.string.menu_home);

        return super.onPrepareOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        super.onOptionsItemSelected(item);

        changeAct(MainActivites.class);

        return false;
    }

    public void changeAct(Class activity) {
        Intent intent = new Intent(getApplicationContext(), activity);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
    }


}