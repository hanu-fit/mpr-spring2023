package hanu.a2_2001040150;

import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Constants {
    public static final ExecutorService EXECUTOR_SERVICE = Executors.newFixedThreadPool(4);
}
