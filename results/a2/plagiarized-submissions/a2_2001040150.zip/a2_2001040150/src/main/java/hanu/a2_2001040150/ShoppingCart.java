package hanu.a2_2001040150;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import hanu.a2_2001040150.adapters.ShoppingCartAdapter;
import hanu.a2_2001040150.db.ProductCartManager;
import hanu.a2_2001040150.models.ProductCart;

public class ShoppingCart extends AppCompatActivity {
    private static TextView tvFinalPrice;

    @SuppressLint({"NotifyDataSetChanged", "SetTextI18n"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shopping_cart);

        double finalPrice = 0.0;
        ProductCartManager CManager = ProductCartManager.getInstance(ShoppingCart.this);
        List<ProductCart> carts = CManager.all();

        RecyclerView rvProductCarts = findViewById(R.id.rvProductCarts);
        ShoppingCartAdapter shoppingCartAdapter = new ShoppingCartAdapter(carts);
        tvFinalPrice = findViewById(R.id.tvFinalPrice);

        if (carts.size() > 0){
            for (ProductCart cart: carts){
                finalPrice += cart.getProductPrice() * cart.getProductQuantity();
            }
        }
        tvFinalPrice.setText(String.valueOf(finalPrice));

        shoppingCartAdapter.notifyDataSetChanged();

        rvProductCarts.setLayoutManager(new LinearLayoutManager(this));
        rvProductCarts.setAdapter(shoppingCartAdapter);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.activity_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.shoppingCart){
            Intent mainIntent = new Intent(ShoppingCart.this, MainActivity.class);
            startActivity(mainIntent);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    public static void increaseFinalPrice(double finalPrice){
        tvFinalPrice.setText(String.valueOf(finalPrice));
    }

    public static void decreaseFinalPrice(double finalPrice){
        tvFinalPrice.setText(String.valueOf(finalPrice));
    }
}