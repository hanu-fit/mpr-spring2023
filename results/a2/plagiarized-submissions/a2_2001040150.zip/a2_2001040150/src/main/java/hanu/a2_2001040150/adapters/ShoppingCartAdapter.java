package hanu.a2_2001040150.adapters;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.os.HandlerCompat;
import androidx.recyclerview.widget.RecyclerView;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;

import hanu.a2_2001040150.Constants;
import hanu.a2_2001040150.R;
import hanu.a2_2001040150.ShoppingCart;
import hanu.a2_2001040150.db.ProductCartManager;
import hanu.a2_2001040150.models.ProductCart;

public class ShoppingCartAdapter extends RecyclerView.Adapter<ShoppingCartAdapter.ShoppingCartHolder> {
    private List<ProductCart> carts;
    public double finalPrice = 0.0;

    public ShoppingCartAdapter(List<ProductCart> carts){
        this.carts =carts;
    }

    @NonNull
    @Override
    public ShoppingCartHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        Context context = parent.getContext();
        LayoutInflater layoutInflater = LayoutInflater.from(context);
        View view = layoutInflater.inflate(R.layout.cart_item, parent, false);
        return new ShoppingCartHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ShoppingCartHolder holder, int position) {
        ProductCart cart = carts.get(position);
        holder.bindingDataToHolder(cart);
    }

    @Override
    public int getItemCount() {
        return carts.size();
    }

    public class ShoppingCartHolder extends RecyclerView.ViewHolder{
        private int productId;
        private String productName;
        private double productPrice;
        private int productQuantity;


        ProductCartManager productCartManager;

        ImageView imvCartImg = itemView.findViewById(R.id.imvCartProductImg);
        TextView tvProductName = itemView.findViewById(R.id.tvProductName);
        TextView tvProductPrice = itemView.findViewById(R.id.tvProductPrice);
        ImageButton imbAddBtn = itemView.findViewById(R.id.imbAddBtn);
        TextView tvProductQuantity = itemView.findViewById(R.id.tvQuantity);
        ImageButton imbMinusBtn = itemView.findViewById(R.id.imbMinusBtn);
        TextView tvTotalProductPrice = itemView.findViewById(R.id.tvTotalProductPrice);



        public ShoppingCartHolder(@NonNull View itemView) {
            super(itemView);
        }

        @SuppressLint({"NotifyDataSetChanged", "SetTextI18n"})
        public void bindingDataToHolder(ProductCart productCart){
            productId = productCart.getProductId();
            productName = productCart.getProductName();
            productPrice = productCart.getProductPrice();
            productQuantity = productCart.getProductQuantity();
            double totalAmount = productPrice * productQuantity;
            productCartManager = ProductCartManager.getInstance(itemView.getContext());


            imbAddBtn.setOnClickListener(view -> {
                productQuantity += 1;
                productCart.setProductQuantity(productQuantity);
                productCartManager.update(productId, productQuantity);
                tvProductQuantity.setText(String.valueOf(productQuantity));
                finalPrice = 0.0;
                for (ProductCart cart: carts){
                    finalPrice += cart.getProductPrice() * cart.getProductQuantity();
                }
//                finalPrice += productPrice;
                ShoppingCart.increaseFinalPrice(finalPrice);
                notifyDataSetChanged();
            });


            imbMinusBtn.setOnClickListener(view -> {
                if (productQuantity  <= 1){
                    carts.remove(productCart);
                    productCartManager.delete(productCart.getId());
                    Log.i("deleteCart", "Card Deleted id: " + productCart.getId());
                }else {
                    productQuantity -= 1;
                    productCart.setProductQuantity(productQuantity);
                    productCartManager.update(productId, productQuantity);
                }
                finalPrice = 0.0;
                for (ProductCart cart: carts){
                    finalPrice += cart.getProductPrice() * cart.getProductQuantity();
                }
//                finalPrice -= productPrice;
                ShoppingCart.decreaseFinalPrice(finalPrice);

                notifyDataSetChanged();
            });

            tvProductName.setText(productName);
            tvProductPrice.setText("₫ " + productPrice);
            tvTotalProductPrice.setText("₫ " + totalAmount);
            tvProductQuantity.setText(Integer.toString(productQuantity));

            Handler handler = HandlerCompat.createAsync(Looper.getMainLooper());

            Constants.EXECUTOR_SERVICE.execute(() -> {
                Bitmap bitmap = loadProductImgBitmap(productCart.getProductImgURL());
                handler.post(() -> imvCartImg.setImageBitmap(bitmap));
            });


        }
    }

    public Bitmap loadProductImgBitmap(String link) {
        try {
            URL url = new URL(link);
            HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
            httpURLConnection.connect();
            InputStream is = httpURLConnection.getInputStream();
            return BitmapFactory.decodeStream(is);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }
}
