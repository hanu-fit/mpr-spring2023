package hanu.a2_2001040150.models;

import java.util.Objects;

public class ProductCart {
    protected long id;
    protected int productId;
    protected String productName;
    protected double productPrice;
    private String productImgURL;
    private int productQuantity;

    public ProductCart() {

    }

    public ProductCart(long id, int productId, String productName, double productPrice, String productImgURL, int quantity) {
        this.id = id;
        this.productId = productId;
        this.productName = productName;
        this.productPrice = productPrice;
        this.productImgURL = productImgURL;
        this.productQuantity = quantity;
    }

    public ProductCart(int productId, String productName, double productPrice, String productImgURL, int quantity) {
        this.productId = productId;
        this.productName = productName;
        this.productPrice = productPrice;
        this.productImgURL = productImgURL;
        this.productQuantity = quantity;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public int getProductId() {
        return productId;
    }

    public void setProductId(int productId) {
        this.productId = productId;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public double getProductPrice() {
        return productPrice;
    }

    public void setProductPrice(double productPrice) {
        this.productPrice = productPrice;
    }

    public String getProductImgURL() {
        return productImgURL;
    }

    public void setProductImgURL(String productImgURL) {
        this.productImgURL = productImgURL;
    }

    public int getProductQuantity() {
        return productQuantity;
    }

    public void setProductQuantity(int productQuantity) {
        this.productQuantity = productQuantity;
    }

    @Override
    public String toString() {
        return "ProductCart{" +
                "id=" + id +
                ", productId=" + productId +
                ", productName='" + productName + '\'' +
                ", productPrice=" + productPrice +
                ", productImgURL='" + productImgURL + '\'' +
                ", quantity=" + productQuantity +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ProductCart that = (ProductCart) o;
        return id == that.id && productId == that.productId && Double.compare(that.productPrice, productPrice) == 0 && productQuantity == that.productQuantity && Objects.equals(productName, that.productName) && Objects.equals(productImgURL, that.productImgURL);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, productId, productName, productPrice, productImgURL, productQuantity);
    }
}
