package hanu.a2_2001040150.db;

import android.database.Cursor;
import android.database.CursorWrapper;

import java.util.ArrayList;
import java.util.List;

import hanu.a2_2001040150.models.ProductCart;

public class ProductCartCursorWrapper extends CursorWrapper {
    public ProductCartCursorWrapper(Cursor cursor){
        super(cursor);
    }

    public ProductCart getProductCart(){
        int id = getInt(getColumnIndex(DbSchema.ProductCartTable.Cols.ID));
        int productId = getInt(getColumnIndex(DbSchema.ProductCartTable.Cols.PRODUCT_ID_COL));
        String productName = getString(getColumnIndex(DbSchema.ProductCartTable.Cols.PRODUCT_NAME_COL));
        double productPrice = getDouble(getColumnIndex(DbSchema.ProductCartTable.Cols.PRODUCT_PRICE_COL));
        String productImgURL = getString(getColumnIndex(DbSchema.ProductCartTable.Cols.PRODUCT_IMG_URL_COL));
        int productQuantity = getInt(getColumnIndex(DbSchema.ProductCartTable.Cols.PRODUCT_QUANTITY_COL));

        return new ProductCart(id, productId, productName, productPrice, productImgURL, productQuantity);
    }

    public List<ProductCart> getProductCarts(){
        List<ProductCart> productCarts = new ArrayList<>();
        moveToFirst();
        while (!isAfterLast()){
            ProductCart productCart = getProductCart();
            productCarts.add(productCart);
            moveToNext();
        }
        return productCarts;
    }
}
