package hanu.a2_2001040150.adapters;

import android.annotation.SuppressLint;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.core.os.HandlerCompat;
import androidx.recyclerview.widget.RecyclerView;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;

import hanu.a2_2001040150.Constants;
import hanu.a2_2001040150.R;
import hanu.a2_2001040150.db.ProductCartManager;
import hanu.a2_2001040150.models.Product;
import hanu.a2_2001040150.models.ProductCart;

public class ProductAdapter extends RecyclerView.Adapter<ProductAdapter.ProductHolder> {
    List<Product> products;

    public ProductAdapter(List<Product> products){
            this.products = products;
        }

    public static class ProductHolder extends RecyclerView.ViewHolder{

        public ProductHolder(@NonNull View itemView) {
            super(itemView);
        }

        @SuppressLint("SetTextI18n")
        public void bindData(Product product){
            ImageView productImg = itemView.findViewById(R.id.imvProduct);
            TextView productName = itemView.findViewById(R.id.tvProductName);
            TextView productPrice = itemView.findViewById(R.id.tvProductPrice);

            Handler handler = HandlerCompat.createAsync(Looper.getMainLooper());

            Constants.EXECUTOR_SERVICE.execute(() -> {
                Bitmap imgBitmap = loadImage(product.getImgUrl());
                handler.post(() -> productImg.setImageBitmap(imgBitmap));
            });
            productName.setText(product.getName());
            productPrice.setText("₫ " + product.getPrice());

            ImageButton addToCartBtn = itemView.findViewById(R.id.imbAddCart);
            addToCartBtn.setOnClickListener(view -> {
                boolean isAdded = false;
                for (ProductCart cart: ProductCartManager.getInstance(view.getContext()).all()){
                    if (cart.getProductId() == product.getId()){
                        cart.setProductQuantity(cart.getProductQuantity() + 1);
                        ProductCartManager.getInstance(view.getContext()).update(cart.getProductId(), cart.getProductQuantity());
                        isAdded = true;
                    }

                }
                if(!isAdded){
                    ProductCart newCart = new ProductCart(product.getId(), product.getName(), product.getPrice(), product.getImgUrl(), 1);
                    ProductCartManager.getInstance(view.getContext()).add(newCart);
                    isAdded = true;
                }
                if (isAdded){
                    Toast.makeText(view.getContext(), "Add to cart", Toast.LENGTH_SHORT).show();
                }
            });

        }

        public Bitmap loadImage(String link){
            try {
                URL url = new URL(link);
                HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
                httpURLConnection.connect();
                InputStream is = httpURLConnection.getInputStream();
                return BitmapFactory.decodeStream(is);
            } catch (IOException e) {
                e.printStackTrace();
            }

            return null;
        }


    }

    @NonNull
    @Override
    public ProductHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater =LayoutInflater.from(parent.getContext());
        View productView = inflater.inflate(R.layout.item, parent, false);
        return new ProductHolder(productView);
    }

    @Override
    public void onBindViewHolder(@NonNull ProductHolder holder, int position) {
        Product product = products.get(position);
        holder.bindData(product);
    }

    @Override
    public int getItemCount() {
        return products.size();
    }




}
