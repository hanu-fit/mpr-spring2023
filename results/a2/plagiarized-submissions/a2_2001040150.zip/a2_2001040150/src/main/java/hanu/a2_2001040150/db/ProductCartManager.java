package hanu.a2_2001040150.db;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;
import android.util.Log;
import android.widget.Toast;

import java.util.List;

import hanu.a2_2001040150.models.ProductCart;

public class ProductCartManager {
    private static ProductCartManager instance;

    public static final String INSERT_STATEMENT = "INSERT INTO "
                            + DbSchema.ProductCartTable.DB_NAME
                            + "(product_id, product_name, product_price, product_img_url, product_quantity) "
                            + "VALUES(?, ?, ?, ?, ?)";
    private DbHelper dbHelper;
    private SQLiteDatabase mDatabase;

    public static ProductCartManager getInstance(Context context){
        if (instance == null) {
            instance = new ProductCartManager(context);
        }
        return instance;
    }

    private ProductCartManager(Context context){
        dbHelper = new DbHelper(context);
        mDatabase = dbHelper.getWritableDatabase();
    }

    public List<ProductCart> all(){
        String sql = "SELECT * FROM product_carts";
        Cursor cursor = mDatabase.rawQuery(sql, null);
        ProductCartCursorWrapper cartCursorWrapper = new ProductCartCursorWrapper(cursor);
        return cartCursorWrapper.getProductCarts();
    }

    public boolean add(ProductCart productCart){
        SQLiteStatement stmt = mDatabase.compileStatement(INSERT_STATEMENT);
        stmt.bindLong(1, productCart.getProductId());
        stmt.bindString(2, productCart.getProductName());
        stmt.bindDouble(3, productCart.getProductPrice());
        stmt.bindString(4, productCart.getProductImgURL());
        stmt.bindLong(5, productCart.getProductQuantity());

        long id = stmt.executeInsert();
        if (id > 0){
            productCart.setId(id);
            Log.i("CartManager", "add: add successfully item id " + productCart.getId());
            return true;
        }
        return false;
    }

    public boolean delete(long id){
        int rs = mDatabase.delete(DbSchema.ProductCartTable.DB_NAME, "id= ?", new String[]{id + ""});
        return rs > 0;
    }

    public boolean update(int productId, int quantity){
        ContentValues contentValues = new ContentValues();
        contentValues.put("product_quantity", quantity);
        int rs = mDatabase.update(DbSchema.ProductCartTable.DB_NAME, contentValues, "product_id= ?", new String[]{productId + ""});
        return rs > 0;
    }

}
