package edu.hanu.a2_2001040135.models;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class BitMapURL {
    public static Bitmap getBitmapFromURL(String imgURL) {
        try {
            InputStream input;
            URL url = new URL(imgURL);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setDoInput(true);
            connection.connect();
            input = connection.getInputStream();
            Bitmap myBitmap = BitmapFactory.decodeStream(input);
            input.close();
            return myBitmap;
        }catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }
}
