package edu.hanu.a2_2001040135.database;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import edu.hanu.a2_2001040135.models.Constant;

public class SQLHelper extends SQLiteOpenHelper {
    public SQLHelper(@Nullable Context context) {
        super(context, Constant.DB_NAME, null, Constant.DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        final String CREATE_TABLES = "CREATE TABLE products(" +
                "id INTEGER PRIMARY KEY," +
                "thumbnail TEXT ," +
                "name TEXT," +
                "unitPrice INTEGER," +
                "category TEXT," +
                "quantity INTEGER)";
        sqLiteDatabase.execSQL(CREATE_TABLES);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL("DROP TABLE " + Constant.DB_TABLE_NAME);

        onCreate(sqLiteDatabase);
    }


}
