package edu.hanu.a2_2001040135.database;

import android.database.Cursor;
import android.database.CursorIndexOutOfBoundsException;
import android.database.CursorWrapper;

import java.util.ArrayList;
import java.util.List;

import edu.hanu.a2_2001040135.models.Product;

public class Wrapper extends CursorWrapper {
    private Cursor cursor;

    public Wrapper(Cursor cursor) {
        super(cursor);
        this.cursor = cursor;
    }

    public List<Product> getProducts() {
        List<Product> productList = new ArrayList<>();
        while (!cursor.isLast()) {
            Product product = getProduct();

            // add note into notes
            productList.add(product);

        }

        return productList;
    }

    public Product getProduct() {
        cursor.moveToNext();

        int idIndex = cursor.getColumnIndex("id");
        int thumbnailIndex = cursor.getColumnIndex("thumbnail");
        int nameIndex = cursor.getColumnIndex("name");
        int categoryIndex = cursor.getColumnIndex("category");
        int unitPriceIndex = cursor.getColumnIndex("unitPrice");
        int quantityIndex = cursor.getColumnIndex("quantity");
        Product product;
        try {
            int id = cursor.getInt(idIndex);
            String thumbnail = cursor.getString(thumbnailIndex);
            String name = cursor.getString(nameIndex);
            String category = cursor.getString(categoryIndex);
            int unitPrice = cursor.getInt(unitPriceIndex);
            int quantity = cursor.getInt(quantityIndex);
            product = new Product(id, thumbnail, name, category, unitPrice, quantity);
        } catch (CursorIndexOutOfBoundsException e) {
            return null;
        }
        return product;
    }
}
