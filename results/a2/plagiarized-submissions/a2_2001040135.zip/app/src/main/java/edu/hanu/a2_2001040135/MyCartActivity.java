package edu.hanu.a2_2001040135;

import android.app.AlertDialog;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

import edu.hanu.a2_2001040135.adapter.MyCartAdapter;
import edu.hanu.a2_2001040135.database.ProductManager;
import edu.hanu.a2_2001040135.models.Product;

public class MyCartActivity extends AppCompatActivity {
    private MyCartAdapter myCartAdapter;

    private ProductManager productManager;

    private List<Product> productList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_cart);

        RecyclerView recyclerViewMyCart = findViewById(R.id.recyclerViewMyCart);
        recyclerViewMyCart.setLayoutManager(new LinearLayoutManager(MyCartActivity.this));

        List<Product> products = new ArrayList<>();
        for (Product p : ProductManager.getInstance(this).listAll()) {
            if (p.getQuantity() > 0) {
                products.add(p);
            }
        }
        productManager = ProductManager.getInstance(MyCartActivity.this);
        productList = products;

        if (productList.size() == 0) {
            new AlertDialog.Builder(this)
                    .setTitle("Empty")
                    .setMessage("You have been not selected product ! Shopping now !")
                    .show();
        }
        Log.i("MyCardActivity", String.valueOf(productList));

        myCartAdapter = new MyCartAdapter(productList);
        recyclerViewMyCart.setAdapter(myCartAdapter);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.main_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }
}