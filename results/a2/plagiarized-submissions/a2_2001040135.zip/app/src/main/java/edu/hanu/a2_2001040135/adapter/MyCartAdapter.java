package edu.hanu.a2_2001040135.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import edu.hanu.a2_2001040135.R;
import edu.hanu.a2_2001040135.database.ProductManager;
import edu.hanu.a2_2001040135.models.BitMapURL;
import edu.hanu.a2_2001040135.models.Product;

public class MyCartAdapter extends RecyclerView.Adapter<MyCartAdapter.MyCardHolder> {
    private List<Product> productList;

    public MyCartAdapter(List<Product> productList) {
        this.productList = productList;
    }

    private ProductManager productManager;

    @NonNull
    @Override
    public MyCardHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_product_cart, parent, false);

        TextView txtViewTotalPrice = parent.getRootView().findViewById(R.id.txtViewTotalPrice);
        MyCardHolder myCardHolder = new MyCardHolder(itemView);
        myCardHolder.setTxtViewTotalPrice(txtViewTotalPrice);

        return myCardHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull MyCardHolder holder, int position) {
        Product product = productList.get(position);
        holder.binding(product);
    }

    @Override
    public int getItemCount() {
        return productList.size();
    }

    protected class MyCardHolder extends RecyclerView.ViewHolder {
        ImageView imgViewThumbnail;

        TextView txtViewProductName_cart;
        TextView txtViewUnitPrice;
        TextView txtViewQuantity;
        TextView txtViewSumPrice_cart;
        TextView txtViewTotalPrice;

        ImageButton imgButtonPlus;
        ImageButton imgButtonMinus;

        public MyCardHolder(@NonNull View itemView) {
            super(itemView);

            imgViewThumbnail = itemView.findViewById(R.id.imgViewThumbnail);

            txtViewProductName_cart = itemView.findViewById(R.id.txtViewProductName_cart);
            txtViewUnitPrice = itemView.findViewById(R.id.txtViewUnitPrice);
            txtViewQuantity = itemView.findViewById(R.id.txtViewQuantity);
            txtViewSumPrice_cart = itemView.findViewById(R.id.txtViewSumPrice_cart);

            imgButtonPlus = itemView.findViewById(R.id.imgButtonPlus);
            imgButtonMinus = itemView.findViewById(R.id.imgButtonMinus);

            productManager = ProductManager.getInstance(itemView.getContext());
        }

        public void setTxtViewTotalPrice(TextView textView) {
            this.txtViewTotalPrice = textView;
        }

        public void binding(Product product) {

            setProductHolderInf(product);
            updateSumPriceText(product);
            updateTotalPriceText();

            imgButtonPlus.setOnClickListener(view -> {
                productManager.addQuantity(product);
                updateProductList();
                updateTotalPriceText();
                updateSumPriceText(product);
            });

            imgButtonMinus.setOnClickListener(view -> {
                productManager.minusQuantity(product);
                updateProductList();
                updateTotalPriceText();
                updateSumPriceText(product);
            });

            imgViewThumbnail.setOnClickListener(view -> {
            });
        }

        private void setProductHolderInf(Product product) {
            imgViewThumbnail.setImageBitmap(BitMapURL.getBitmapFromURL(product.getThumbnail()));
            txtViewProductName_cart.setText(product.getName());
            txtViewUnitPrice.setText(String.valueOf(product.getUnitPrice()));
            txtViewQuantity.setText(String.valueOf(product.getQuantity()));
        }

        private void updateSumPriceText(Product product) {
            txtViewSumPrice_cart.setText(String.valueOf(product.getUnitPrice() * product.getQuantity()));
        }

        private void updateTotalPriceText() {
            int totalPrice = productManager.listAll().stream().mapToInt(p -> (p.getQuantity() * p.getUnitPrice())).sum();
            txtViewTotalPrice.setText(String.valueOf(totalPrice));
        }

        private void updateProductList() {
            productList.clear();
            productManager.listAll().forEach(x -> {
                if (x.getQuantity() > 0) {
                    productList.add(x);
                }
            });
            notifyDataSetChanged();
        }
    }
}
