package edu.hanu.a2_2001040135.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import edu.hanu.a2_2001040135.R;
import edu.hanu.a2_2001040135.database.ProductManager;
import edu.hanu.a2_2001040135.models.BitMapURL;
import edu.hanu.a2_2001040135.models.Product;

public class productAdapter extends RecyclerView.Adapter<productAdapter.ProductHolder> {

    private List<Product> productList;

    public productAdapter(List<Product> productList) {
        this.productList = productList;
    }

    private ProductManager productManager;

    protected class ProductHolder extends RecyclerView.ViewHolder {
        private final ImageView imgViewProduct;

        private final TextView txtViewProductDescription;
        private final TextView txtViewUnitPrice;

        public ProductHolder(@NonNull View itemView) {
            super(itemView);

            imgViewProduct = itemView.findViewById(R.id.imgViewProduct);
            txtViewProductDescription = itemView.findViewById(R.id.txtViewProductDescription);
            txtViewUnitPrice = itemView.findViewById(R.id.txtViewUnitPrice);
            ImageButton imgBtnAddToCart = itemView.findViewById(R.id.imgBtnAddToCart);

            imgBtnAddToCart.setOnClickListener(view -> {
                int position = getAdapterPosition();
                int id = position + 1;
                productManager = ProductManager.getInstance(view.getContext());
                Product product = productList.get(position);

                if (!productManager.isExistById(id)) {
                    productManager.addProducts(product);
                    return;
                }
                productManager.addQuantity(product);
            });
        }
    }

    @NonNull
    @Override
    public ProductHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_product_main, parent, false);

        return new ProductHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull ProductHolder holder, int position) {
        Product product = productList.get(position);

        holder.imgViewProduct.setImageBitmap(BitMapURL.getBitmapFromURL(product.getThumbnail()));
        holder.txtViewProductDescription.setText(product.getName());
        holder.txtViewUnitPrice.setText(String.valueOf(product.getUnitPrice()));
    }


    @Override
    public int getItemCount() {
        return productList.size();
    }

    public void filterList(List<Product> filteredList) {
        // below line is to add our filtered
        // list in our course array list.
        productList = filteredList;
        // below line is to notify our adapter
        // as change in recycler view data.
        notifyDataSetChanged();
    }
}
