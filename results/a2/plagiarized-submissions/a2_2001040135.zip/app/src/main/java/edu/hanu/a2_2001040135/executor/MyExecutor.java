package edu.hanu.a2_2001040135.executor;

import android.app.Activity;
import android.util.JsonReader;
import android.widget.SearchView;
import android.widget.Toast;

import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Executor;

import javax.net.ssl.HttpsURLConnection;

import edu.hanu.a2_2001040135.R;
import edu.hanu.a2_2001040135.adapter.productAdapter;
import edu.hanu.a2_2001040135.database.ProductManager;
import edu.hanu.a2_2001040135.models.Constant;
import edu.hanu.a2_2001040135.models.Product;

public class MyExecutor implements Executor {
    private InputStream inputStream;

    private InputStreamReader inputStreamReader;

    private JsonReader jsonReader;

    private final Activity contextParent;

    private List<Product> productList;

    private productAdapter productAdapter;


    public MyExecutor(Activity contextParent) {
        this.contextParent = contextParent;
    }

    private void filter(String query) {
        // creating a new array list to filter our data.
        List<Product> filteredList = new ArrayList<>();

        // running a for loop to compare elements.
        for (Product item : productList) {
            // checking if the entered string matched with any item of our recycler view.
            if (item.getName().toLowerCase().contains(query.toLowerCase())) {
                // if the item is matched we are
                // adding it to our filtered list.
                filteredList.add(item);
            }
        }
        if (filteredList.isEmpty()) {
            // if no item is added in filtered list we are
            // displaying a toast message as no data found.
            Toast.makeText(contextParent, "No product found", Toast.LENGTH_SHORT).show();
            productAdapter.filterList(filteredList);
        } else {
            // at last we are passing that filtered
            // list to our adapter class.
            productAdapter.filterList(filteredList);
        }
    }
    private void compareAPIvsDatabase(){
        ProductManager manager = ProductManager.getInstance(contextParent);
        List<Product> dbList = manager.listAll();
        for (int i = 0; i < productList.size(); i++) {
            if (!manager.isEmpty()) {
                manager.clear();
                manager.addProductList(productList);
                break;
            }
            Product dbProduct = dbList.get(i);
            Product listProduct = productList.get(i);
            if ((dbProduct.getId() != listProduct.getId())
                    || !dbProduct.getThumbnail().equals(listProduct.getThumbnail())
                    || !dbProduct.getName().equals(listProduct.getName())
                    || (dbProduct.getUnitPrice() != listProduct.getUnitPrice())) {
                manager.clear();
                manager.addProductList(productList);
                break;
            }
        }
    }

    @Override
    public void execute(Runnable runnable) {
        productList = new ArrayList<>();
        try {
            URL cartApiEndpoint = new URL(Constant.PRODUCT_LIST_API);
            // open connection to the URL
            HttpsURLConnection APIConnection = (HttpsURLConnection) cartApiEndpoint.openConnection();

            // check status of connection
            if (APIConnection.getResponseCode() == 200) {
                // get input stream from connection
                inputStream = APIConnection.getInputStream();
                // read stream
                inputStreamReader = new InputStreamReader(inputStream, StandardCharsets.UTF_8);
                // use JsonReader
                jsonReader = new JsonReader(inputStreamReader);
                // '[' at begin -> begin is a array
                jsonReader.beginArray();
                while (jsonReader.hasNext()) {
                    // next is '{' -> next is object
                    jsonReader.beginObject();

                    // id
                    jsonReader.nextName();
                    int id = jsonReader.nextInt();
                    // thumbnail link
                    jsonReader.nextName();
                    String thumbnail = jsonReader.nextString();
                    // name
                    jsonReader.nextName();
                    String name = jsonReader.nextString();
                    // category
                    jsonReader.nextName();
                    String category = jsonReader.nextString();
                    // uniPrice
                    jsonReader.nextName();
                    int unitPrice = jsonReader.nextInt();

                    productList.add(new Product(id, thumbnail, name, category, unitPrice, 1));
                    jsonReader.endObject();
                }
            }
            compareAPIvsDatabase();
        } catch (IOException e) {
            e.printStackTrace();
        }
//        runnable.run();
        contextParent.runOnUiThread(() -> {
            Toast.makeText(contextParent, "Welcome", Toast.LENGTH_SHORT).show();

            //get ref to recycle view
            RecyclerView recyclerViewFriends = contextParent.findViewById(R.id.recyclerViewProduct);
            // Create layout manager
            GridLayoutManager gridLayoutManager = new GridLayoutManager(contextParent, 2);

            // set layout manager
            recyclerViewFriends.setLayoutManager(gridLayoutManager);

            // init adapter

            productAdapter = new productAdapter(productList);

            ProductManager.getInstance(contextParent)
                    .listAll()
                    .stream()
                    .forEach(i -> System.out.println("??" + i.toString()));
            // bind recyclerview with adapter
            recyclerViewFriends.setAdapter(productAdapter);

            // get ref of search view
            SearchView searchView = contextParent.findViewById(R.id.searchViewBar);

            // listen for action
            searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
                // filter product on search icon clicked
                @Override
                public boolean onQueryTextSubmit(String query) {
                    filter(query);
                    return false;
                }

                // filter product on text change
                @Override
                public boolean onQueryTextChange(String query) {
                    filter(query);
                    return false;
                }
            });
        });
    }
}
