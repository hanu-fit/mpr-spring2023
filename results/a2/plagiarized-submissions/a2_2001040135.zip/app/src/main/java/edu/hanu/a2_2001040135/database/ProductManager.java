package edu.hanu.a2_2001040135.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import java.util.List;

import edu.hanu.a2_2001040135.models.Constant;
import edu.hanu.a2_2001040135.models.Product;

public class ProductManager {

    private final SQLiteDatabase database;

    private static ProductManager instance;

    private ProductManager(Context context) {
        SQLHelper sqlHelper = new SQLHelper(context);
        database = sqlHelper.getWritableDatabase();
    }

    public static ProductManager getInstance(Context context) {
        if (instance == null) {
            instance = new ProductManager(context);
        }
        return instance;
    }

    public Product getById(int id) {
        Cursor cursor = database.rawQuery("SELECT * FROM products WHERE id = " + id, null);
        cursor.moveToFirst();
        if (cursor.getColumnCount() > 0) {
            int thumbnailIndex = cursor.getColumnIndex("thumbnail");
            int nameIndex = cursor.getColumnIndex("name");
            int unitPriceIndex = cursor.getColumnIndex("unitPrice");
            int categoryIndex = cursor.getColumnIndex("category");
            int quantityIndex = cursor.getColumnIndex("quantity");

            String thumbnail = cursor.getString(thumbnailIndex);
            String name = cursor.getString(nameIndex);
            String category = cursor.getString(categoryIndex);
            int unitPrice = cursor.getInt(unitPriceIndex);
            int quantity = cursor.getInt(quantityIndex);
            return new Product(id, thumbnail, name, category, unitPrice, quantity);
        }
        return null;
    }

    public List<Product> listAll() {
        Cursor cursor = database.rawQuery("SELECT * FROM " + Constant.DB_TABLE_NAME, null);
        Wrapper productCursorWrapper = new Wrapper(cursor);
        return productCursorWrapper.getProducts();
    }

    public void addProducts(Product product) {
        ContentValues values = new ContentValues();
        values.put(Constant.DB_FIELD_ID, product.getId());
        values.put(Constant.DB_FIELD_THUMBNAIL, product.getThumbnail());
        values.put(Constant.DB_FIELD_NAME, product.getName());
        values.put(Constant.DB_FIELD_CATEGORY, product.getCategory());
        values.put(Constant.DB_FIELD_UNIT_PRICE, product.getUnitPrice());
        values.put(Constant.DB_FIELD_QUANTITY, 1);

        Log.d("NoteManager", "added Product");
        database.insert(Constant.DB_TABLE_NAME, null, values);
    }

    public void addProductList(List<Product> productList) {
        productList.forEach(product -> {
            ContentValues values = new ContentValues();
            values.put(Constant.DB_FIELD_ID, product.getId());
            values.put(Constant.DB_FIELD_THUMBNAIL, product.getThumbnail());
            values.put(Constant.DB_FIELD_NAME, product.getName());
            values.put(Constant.DB_FIELD_CATEGORY, product.getCategory());
            values.put(Constant.DB_FIELD_UNIT_PRICE, product.getUnitPrice());
            values.put(Constant.DB_FIELD_QUANTITY, 0);
            database.insert(Constant.DB_TABLE_NAME, null, values);
        });

        Log.d("NoteManager", "added Product List" + productList);
    }

    public void addQuantity(Product product) {
        int id = product.getId();
        Product productUpdate = getById(id);
        ContentValues contentValues = new ContentValues();
        contentValues.put(Constant.DB_FIELD_ID, productUpdate.getId());
        contentValues.put(Constant.DB_FIELD_THUMBNAIL, productUpdate.getThumbnail());
        contentValues.put(Constant.DB_FIELD_NAME, productUpdate.getName());
        contentValues.put(Constant.DB_FIELD_UNIT_PRICE, productUpdate.getUnitPrice());
        contentValues.put(Constant.DB_FIELD_CATEGORY, product.getCategory());
        contentValues.put(Constant.DB_FIELD_QUANTITY, productUpdate.getQuantity() + 1);
        database.update(Constant.DB_TABLE_NAME, contentValues, Constant.ID + " =" + id, null);
        Log.d("ProductManager", "Add quantity " + getById(product.getId()));
    }

    public void minusQuantity(Product product) {
        int id = product.getId();
        Product productUpdate = getById(id);
        ContentValues contentValues = new ContentValues();
        contentValues.put(Constant.DB_FIELD_ID, productUpdate.getId());
        contentValues.put(Constant.DB_FIELD_THUMBNAIL, productUpdate.getThumbnail());
        contentValues.put(Constant.DB_FIELD_NAME, productUpdate.getName());
        contentValues.put(Constant.DB_FIELD_CATEGORY, product.getCategory());
        contentValues.put(Constant.DB_FIELD_UNIT_PRICE, productUpdate.getUnitPrice());
        contentValues.put(Constant.DB_FIELD_QUANTITY, productUpdate.getQuantity() - 1);
        database.update(Constant.DB_TABLE_NAME, contentValues, Constant.ID + " =" + id, null);
        Log.d("ProductManager", "Minus quantity " + getById(product.getId()));
    }

    public void clear() {
        database.delete(Constant.DB_TABLE_NAME, "1", null);
    }

    public boolean isEmpty() {
        Cursor cursor = database.rawQuery("SELECT * FROM products", null);
        return cursor.moveToFirst();
    }

    public boolean isExistById(int id) {
        Cursor cursor = database.rawQuery("SELECT * FROM products WHERE id = " + id, null);
        return cursor.moveToFirst();
    }

    @Override
    protected void finalize() throws Throwable {
        super.finalize();
        // close connection
        database.close();
    }
}
